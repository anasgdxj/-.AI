part of 'app_shell.dart';

String _localizedCatalogName(dynamic entity, String fallback) {
  final translations = entity['translations'] as List? ?? [];
  final locale = darbLocale.value.languageCode;
  for (final item in translations) {
    if (item is Map && item['locale'] == locale) return item['name'].toString();
  }
  for (final item in translations) {
    if (item is Map && item['locale'] == 'ar') return item['name'].toString();
  }
  return translations.isEmpty
      ? dt(fallback)
      : translations.first['name']?.toString() ?? dt(fallback);
}

String _localizedCatalogDescription(dynamic entity) {
  final translations = entity['translations'] as List? ?? [];
  final locale = darbLocale.value.languageCode;
  for (final item in translations) {
    if (item is Map && item['locale'] == locale) {
      final desc = item['description']?.toString().trim() ?? '';
      if (desc.isNotEmpty) return desc;
    }
  }
  for (final item in translations) {
    if (item is Map && item['locale'] == 'ar') {
      final desc = item['description']?.toString().trim() ?? '';
      if (desc.isNotEmpty) return desc;
    }
  }
  return '';
}

class _VendorTile extends StatelessWidget {
  final Map<String, dynamic> vendor;
  final String cityId;
  const _VendorTile({required this.vendor, required this.cityId});

  @override
  Widget build(BuildContext context) {
    final name = _localizedCatalogName(vendor, 'متجر');
    return DarbFadeSlide(
      child: Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: DarbSurfaceCard(
          padding: const EdgeInsets.all(12),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => VendorCatalog(
                vendorId: vendor['id'].toString(),
                name: name,
                cityId: cityId,
              ),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: DarbColors.surfaceAlt,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(
                  Icons.storefront,
                  color: DarbColors.brandForeground,
                  size: 28,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: DarbColors.ink,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      dt('${vendor['_count']?['products'] ?? 0} منتج متاح'),
                      style: TextStyle(color: DarbColors.muted, fontSize: 12),
                    ),
                  ],
                ),
              ),
              Icon(DarbIcons.chevronForward(context), color: DarbColors.muted),
            ],
          ),
        ),
      ),
    );
  }
}

class VendorCatalog extends StatefulWidget {
  final String vendorId, name, cityId;
  const VendorCatalog({
    super.key,
    required this.vendorId,
    required this.name,
    required this.cityId,
  });
  @override
  State<VendorCatalog> createState() => _VendorCatalogState();
}

String _productName(dynamic p) => _localizedCatalogName(p, 'منتج');

class _VendorCatalogState extends State<VendorCatalog> {
  bool loading = true;
  String? error;
  int _loadGeneration = 0;
  List products = [];
  final Map<String, Map<String, dynamic>> cart = {};
  final TextEditingController search = TextEditingController();

  @override
  void initState() {
    super.initState();
    darbLocale.addListener(_onLocaleChanged);
    search.addListener(_refresh);
    _load();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  void _onLocaleChanged() => _load();

  @override
  void dispose() {
    darbLocale.removeListener(_onLocaleChanged);
    search.removeListener(_refresh);
    search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final generation = ++_loadGeneration;
    if (mounted) setState(() => loading = true);
    try {
      final loaded = await Api.instance.get(
        '/vendors/${widget.vendorId}/products?locale=${darbLocale.value.languageCode}',
      ) as List;
      if (generation != _loadGeneration) return;
      products = loaded;
      error = null;
    } catch (e) {
      if (generation == _loadGeneration) error = e.toString();
    } finally {
      if (mounted && generation == _loadGeneration) {
        setState(() => loading = false);
      }
    }
  }

  void _add(dynamic p) {
    final id = p['id'].toString();
    setState(() {
      final old = cart[id];
      cart[id] = {
        'productId': id,
        'name': _productName(p),
        'price': p['basePrice'],
        'currency': p['currency'],
        'quantity': (old?['quantity'] ?? 0) + 1,
      };
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(dt('أضيف ${_productName(p)} إلى السلة')),
        duration: const Duration(milliseconds: 900),
      ),
    );
  }

  void _changeQuantity(dynamic p, int delta) {
    final id = p['id'].toString();
    final current = cart[id]?['quantity'] as int? ?? 0;
    final next = current + delta;
    setState(() {
      if (next <= 0) {
        cart.remove(id);
      } else {
        cart[id] = {
          'productId': id,
          'name': _productName(p),
          'price': p['basePrice'],
          'currency': p['currency'],
          'quantity': next,
        };
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final quantity = cart.values.fold<int>(
      0,
      (total, item) => total + (item['quantity'] as int),
    );
    final cartSubtotal = cart.values.fold<double>(
      0,
      (sum, item) =>
          sum +
          ((double.tryParse(item['price'].toString()) ?? 0) *
              (item['quantity'] as int)),
    );
    final cartCurrency =
        cart.isEmpty ? '' : cart.values.first['currency']?.toString() ?? '';
    final query = search.text.trim().toLowerCase();
    final visibleProducts = products
        .where((p) => _productName(p).toLowerCase().contains(query))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.name, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 10),
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                decoration: BoxDecoration(
                  color: DarbColors.surfaceAlt,
                  borderRadius: BorderRadius.circular(DarbRadius.pill),
                  border: Border.all(color: DarbColors.line),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.shopping_bag_outlined,
                      size: 17,
                      color: DarbColors.brandForeground,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '$quantity',
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: DarbColors.brandForeground,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      body: loading
          ? ListView(
              padding: const EdgeInsets.all(18),
              children: List.generate(
                4,
                (_) => const Padding(
                  padding: EdgeInsets.only(bottom: 11),
                  child: DarbSkeletonCard(lines: 2),
                ),
              ),
            )
          : error != null
              ? ListView(
                  padding: const EdgeInsets.all(18),
                  children: [_ErrorPanel(message: error!, retry: _load)],
                )
              : products.isEmpty
                  ? Center(child: _EmptyPanel(text: dt('لا توجد منتجات متاحة')))
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
                        children: [
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              gradient: DarbColors.heroGradient,
                              borderRadius: BorderRadius.circular(DarbRadius.xl),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.storefront_rounded,
                                  color: DarbColors.lime,
                                  size: 25,
                                ),
                                const SizedBox(width: 11),
                                Expanded(
                                  child: Text(
                                    dt('منتجات المتجر'),
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 17,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ),
                                Text(
                                  '${products.length}',
                                  style: TextStyle(
                                    color: DarbColors.lime,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 15),
                          TextField(
                            controller: search,
                            textInputAction: TextInputAction.search,
                            decoration: InputDecoration(
                              hintText: dt('ابحث عن منتج...'),
                              prefixIcon: Icon(
                                Icons.search_rounded,
                                color: DarbColors.brandForeground,
                              ),
                              suffixIcon: search.text.isEmpty
                                  ? null
                                  : IconButton(
                                      onPressed: search.clear,
                                      icon: const Icon(Icons.close_rounded),
                                    ),
                            ),
                          ),
                          const SizedBox(height: 13),
                          if (visibleProducts.isEmpty)
                            _EmptyPanel(
                              text: query.isEmpty
                                  ? dt('لا توجد منتجات متاحة')
                                  : dt('لم نعثر على منتجات مطابقة'),
                            ),
                          for (var index = 0;
                              index < visibleProducts.length;
                              index++)
                            DarbFadeSlide(
                              delay: DarbMotion.cappedStaggerDelay(index),
                              child: Builder(
                                builder: (context) {
                                  final product = visibleProducts[index];
                                  final selected =
                                      cart[product['id'].toString()]?['quantity']
                                              as int? ??
                                          0;
                                  return Padding(
                                    padding: const EdgeInsets.only(bottom: 11),
                                    child: DarbSurfaceCard(
                                      padding: const EdgeInsets.all(13),
                                      child: Row(
                                        children: [
                                          Container(
                                            width: 58,
                                            height: 58,
                                            decoration: BoxDecoration(
                                              color: DarbColors.surfaceAlt,
                                              borderRadius:
                                                  BorderRadius.circular(16),
                                            ),
                                            child: Icon(
                                              Icons.inventory_2_outlined,
                                              color: DarbColors.brandForeground,
                                              size: 26,
                                            ),
                                          ),
                                          const SizedBox(width: 12),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  _productName(product),
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.w900,
                                                    fontSize: 14,
                                                    color: DarbColors.ink,
                                                  ),
                                                ),
                                                if (_localizedCatalogDescription(
                                                        product)
                                                    .isNotEmpty) ...[
                                                  const SizedBox(height: 3),
                                                  Text(
                                                    _localizedCatalogDescription(
                                                        product),
                                                    maxLines: 2,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: TextStyle(
                                                      color: DarbColors.muted,
                                                      fontSize: 11.5,
                                                      height: 1.35,
                                                    ),
                                                  ),
                                                ],
                                                const SizedBox(height: 6),
                                                Text(
                                                  '${product['basePrice']} ${product['currency']}',
                                                  style: TextStyle(
                                                    color: DarbColors
                                                        .brandForeground,
                                                    fontWeight: FontWeight.w900,
                                                    fontSize: 13,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          selected == 0
                                              ? IconButton.filledTonal(
                                                  tooltip: dt('إضافة إلى السلة'),
                                                  onPressed: () => _add(product),
                                                  icon: const Icon(
                                                    Icons.add_rounded,
                                                  ),
                                                  style: IconButton.styleFrom(
                                                    backgroundColor:
                                                        DarbColors.surfaceAlt,
                                                    foregroundColor: DarbColors
                                                        .brandForeground,
                                                  ),
                                                )
                                              : Container(
                                                  padding: const EdgeInsets
                                                      .symmetric(
                                                    horizontal: 4,
                                                    vertical: 4,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color:
                                                        DarbColors.surfaceAlt,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                      DarbRadius.pill,
                                                    ),
                                                    border: Border.all(
                                                      color: DarbColors.line,
                                                    ),
                                                  ),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      IconButton(
                                                        onPressed: () =>
                                                            _changeQuantity(
                                                          product,
                                                          -1,
                                                        ),
                                                        icon: const Icon(
                                                          Icons.remove_rounded,
                                                        ),
                                                        iconSize: 17,
                                                        constraints:
                                                            const BoxConstraints
                                                                .tightFor(
                                                          width: 30,
                                                          height: 30,
                                                        ),
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .symmetric(
                                                          horizontal: 4,
                                                        ),
                                                        child: Text(
                                                          '$selected',
                                                          style: TextStyle(
                                                            fontWeight:
                                                                FontWeight.w900,
                                                            color: DarbColors
                                                                .brandForeground,
                                                          ),
                                                        ),
                                                      ),
                                                      IconButton(
                                                        onPressed: () =>
                                                            _changeQuantity(
                                                          product,
                                                          1,
                                                        ),
                                                        icon: const Icon(
                                                          Icons.add_rounded,
                                                        ),
                                                        iconSize: 17,
                                                        constraints:
                                                            const BoxConstraints
                                                                .tightFor(
                                                          width: 30,
                                                          height: 30,
                                                        ),
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                        ],
                      ),
                    ),
      bottomNavigationBar: quantity == 0
          ? null
          : SafeArea(
              minimum: const EdgeInsets.fromLTRB(18, 8, 18, 12),
              child: FilledButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CheckoutScreen(
                      vendorId: widget.vendorId,
                      cityId: widget.cityId,
                      items: cart.values.toList(),
                    ),
                  ),
                ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.shopping_bag_outlined, size: 18),
                      const SizedBox(width: 8),
                      Flexible(
                        child: Text(
                          dt('متابعة إلى تأكيد الطلب • $quantity'),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (cartSubtotal > 0 && cartCurrency.isNotEmpty) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: DarbColors.lime,
                            borderRadius: BorderRadius.circular(DarbRadius.pill),
                          ),
                          child: Text(
                            '${cartSubtotal == cartSubtotal.roundToDouble() ? cartSubtotal.toInt() : cartSubtotal.toStringAsFixed(1)} $cartCurrency',
                            style: TextStyle(
                              color: DarbColors.forest,
                              fontSize: 11.5,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
      );
    }
  }

class CheckoutScreen extends StatefulWidget {
  final String vendorId, cityId;
  final List<Map<String, dynamic>> items;

  const CheckoutScreen({
    super.key,
    required this.vendorId,
    required this.cityId,
    required this.items,
  });

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  bool loading = true;
  bool quoting = false;
  bool sending = false;
  bool addingAddress = false;
  bool locating = false;
  String? error;
  String? quoteError;
  Map<String, dynamic>? quote;
  String? addressId;
  List addresses = [];
  final notes = TextEditingController();
  final _addressFormKey = GlobalKey<FormState>();
  int _loadGeneration = 0;
  int _quoteGeneration = 0;

  bool get _selectedAddressHasLocation => addresses.any(
        (address) =>
            address['id']?.toString() == addressId &&
            address['hasLocation'] == true,
      );

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    notes.dispose();
    super.dispose();
  }

  Future<void> _fetchQuote() async {
    final targetAddressId = addressId;
    if (targetAddressId == null || widget.items.isEmpty) {
      if (mounted) {
        setState(() {
          quoting = false;
          quote = null;
          quoteError = null;
        });
      }
      return;
    }
    final generation = ++_quoteGeneration;
    if (mounted) {
      setState(() {
        quoting = true;
        quoteError = null;
      });
    }
    try {
      final result = await Api.instance.post('/orders/quote', {
        'cityId': widget.cityId,
        'addressId': targetAddressId,
        'vendorId': widget.vendorId,
        'items': widget.items
            .map((item) => {
                  'productId': item['productId'],
                  'quantity': item['quantity'],
                })
            .toList(),
      });
      if (generation != _quoteGeneration || !mounted) return;
      if (result is Map) {
        setState(() {
          quote = Map<String, dynamic>.from(result);
          quoteError = null;
        });
      }
    } catch (e) {
      if (generation == _quoteGeneration && mounted) {
        setState(() {
          quote = null;
          quoteError = _orderError(e);
        });
      }
    } finally {
      if (generation == _quoteGeneration && mounted) {
        setState(() => quoting = false);
      }
    }
  }

  Future<void> _load() async {
    final generation = ++_loadGeneration;
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }
    try {
      final result = await Api.instance.get('/addresses');
      if (result is! List) throw Exception(dt('تعذر قراءة عناوين التوصيل'));
      if (generation != _loadGeneration) return;
      addresses = result;
      if (!addresses.any((address) => address['id']?.toString() == addressId)) {
        addressId = addresses.isEmpty ? null : addresses.first['id'].toString();
      }
      if (addressId != null) {
        unawaited(_fetchQuote());
      }
    } catch (e) {
      if (generation == _loadGeneration) error = e.toString();
    } finally {
      if (mounted && generation == _loadGeneration) {
        setState(() => loading = false);
      }
    }
  }

  Future<void> _newAddress() async {
    final label = TextEditingController();
    final details = TextEditingController();
    double? latitude;
    double? longitude;
    String? locationError;

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, refreshDialog) => AlertDialog(
          title: Text(dt('إضافة عنوان توصيل')),
          content: SingleChildScrollView(
            child: Form(
              key: _addressFormKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: label,
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                      labelText: dt('اسم العنوان (اختياري)'),
                      prefixIcon: const Icon(Icons.bookmark_outline_rounded),
                    ),
                    validator: (value) => (value?.trim().length ?? 0) > 40
                        ? dt('اسم العنوان طويل جداً')
                        : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: details,
                    minLines: 2,
                    maxLines: 4,
                    maxLength: 500,
                    textInputAction: TextInputAction.newline,
                    decoration: InputDecoration(
                      labelText: dt('العنوان بالتفصيل'),
                      hintText: dt('الحي، الشارع، البناء، الطابق...'),
                      prefixIcon: const Icon(Icons.location_on_outlined),
                      alignLabelWithHint: true,
                    ),
                    validator: (value) {
                      final text = value?.trim() ?? '';
                      if (text.isEmpty) return dt('أدخل تفاصيل العنوان');
                      if (text.length > 500) {
                        return dt('تفاصيل العنوان طويلة جداً');
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 4),
                  OutlinedButton.icon(
                    onPressed: locating
                        ? null
                        : () async {
                            refreshDialog(() {
                              locating = true;
                              locationError = null;
                            });
                            try {
                              if (!await Geolocator.isLocationServiceEnabled()) {
                                throw Exception(
                                  dt('فعّل خدمة الموقع في هاتفك أولاً'),
                                );
                              }
                              var permission =
                                  await Geolocator.checkPermission();
                              if (permission == LocationPermission.denied) {
                                permission =
                                    await Geolocator.requestPermission();
                              }
                              if (permission == LocationPermission.denied ||
                                  permission ==
                                      LocationPermission.deniedForever) {
                                throw Exception(
                                  dt('يلزم السماح للتطبيق بالوصول إلى موقعك'),
                                );
                              }
                              final point = await Geolocator.getCurrentPosition(
                                locationSettings: const LocationSettings(
                                  accuracy: LocationAccuracy.high,
                                  timeLimit: Duration(seconds: 20),
                                ),
                              );
                              latitude = point.latitude;
                              longitude = point.longitude;
                              if (dialogContext.mounted) refreshDialog(() {});
                            } catch (e) {
                              locationError = e.toString();
                              if (dialogContext.mounted) refreshDialog(() {});
                            } finally {
                              if (dialogContext.mounted) {
                                refreshDialog(() => locating = false);
                              }
                            }
                          },
                    icon: locating
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Icon(
                            latitude == null
                                ? Icons.my_location_rounded
                                : Icons.check_circle_rounded,
                          ),
                    label: Text(
                      locating
                          ? dt('جارٍ تحديد الموقع...')
                          : latitude == null
                              ? dt('استخدام موقعي الحالي')
                              : dt('تم تحديد الموقع'),
                    ),
                  ),
                  if (locationError != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        locationError!,
                        style: TextStyle(color: DarbColors.danger, fontSize: 12),
                      ),
                    ),
                  if (latitude != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Row(
                        children: [
                          Icon(
                            Icons.verified_rounded,
                            color: DarbColors.success,
                            size: 16,
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              dt('سيتم حفظ إحداثيات هذا العنوان لحساب مسافة التوصيل'),
                              style: TextStyle(
                                color: DarbColors.success,
                                fontSize: 11,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed:
                  locating ? null : () => Navigator.pop(dialogContext, false),
              child: Text(dt('إلغاء')),
            ),
            FilledButton(
              onPressed: locating
                  ? null
                  : () {
                      if (_addressFormKey.currentState?.validate() ?? false) {
                        Navigator.pop(dialogContext, true);
                      }
                    },
              child: Text(dt('حفظ العنوان')),
            ),
          ],
        ),
      ),
    );

    if (saved == true) {
      if (mounted) {
        setState(() {
          addingAddress = true;
          error = null;
        });
      }
      try {
        final created = await Api.instance.post('/addresses', {
          'label': label.text.trim(),
          'details': details.text.trim(),
          if (latitude != null && longitude != null) 'latitude': latitude,
          if (latitude != null && longitude != null) 'longitude': longitude,
        });
        if (created is! Map || created['id'] == null) {
          throw Exception(dt('لم يتم حفظ العنوان بشكل صحيح'));
        }
        if (mounted) {
          setState(() {
            addresses.insert(0, {
              ...Map<String, dynamic>.from(created),
              'hasLocation': latitude != null && longitude != null,
            });
            addressId = created['id'].toString();
            error = null;
          });
          unawaited(_fetchQuote());
        }
      } catch (e) {
        if (mounted) setState(() => error = e.toString());
      } finally {
        if (mounted) setState(() => addingAddress = false);
      }
    }
    label.dispose();
    details.dispose();
  }

  String _orderError(Object exception) {
    final raw = exception.toString();
    if (raw.contains('حدد موقع عنوان التوصيل')) {
      return dt('هذا الطلب يحتاج إلى إحداثيات عنوان التوصيل لحساب الأجرة. أضف عنواناً جديداً وحدد موقعك بدقة.');
    }
    if (raw.contains('لم يتم إعداد رسوم التوصيل')) {
      return dt('التوصيل غير مفعّل لهذه المدينة حالياً. لم يتم إرسال الطلب.');
    }
    if (raw.contains('بعض المنتجات لم تعد متاحة') ||
        raw.contains('نفدت كمية أحد المنتجات')) {
      return dt('تغيّرت توفر المنتجات أو الكمية. ارجع إلى المتجر وحدّث سلتك قبل المحاولة.');
    }
    if (raw.contains('المتجر غير متاح')) {
      return dt('هذا المتجر غير متاح لاستقبال الطلبات حالياً.');
    }
    return raw;
  }

  Future<void> _submit() async {
    if (sending) return;
    if (widget.items.isEmpty ||
        widget.items.any((item) => (item['quantity'] as int? ?? 0) < 1)) {
      setState(() => error = dt('السلة فارغة أو تحتوي على كمية غير صالحة'));
      return;
    }
    if (addressId == null ||
        !addresses.any((address) => address['id']?.toString() == addressId)) {
      setState(
        () => error = dt('اختر عنوان توصيل صالحاً أو أضف عنواناً جديداً'),
      );
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      sending = true;
      error = null;
    });
    try {
      final result = await Api.instance.post('/orders', {
        'cityId': widget.cityId,
        'addressId': addressId,
        'vendorId': widget.vendorId,
        'items': widget.items
            .map((item) => {
                  'productId': item['productId'],
                  'quantity': item['quantity'],
                })
            .toList(),
        'notes': notes.text.trim(),
      });
      if (!mounted) return;
      if (result is! Map || result['id'] == null) {
        throw Exception(
          dt('تم إرسال الطلب لكن تعذر قراءة تفاصيل التأكيد. تحقق من صفحة طلباتي قبل إعادة المحاولة.'),
        );
      }
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) =>
              OrderCreatedScreen(order: Map<String, dynamic>.from(result)),
        ),
      );
    } catch (e) {
      if (mounted) setState(() => error = _orderError(e));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final subtotal = widget.items.fold<double>(
      0,
      (sum, item) =>
          sum +
          ((double.tryParse(item['price'].toString()) ?? 0) *
              (item['quantity'] as int)),
    );
    final currency =
        widget.items.isEmpty ? '' : widget.items.first['currency']?.toString() ?? '';

    return Scaffold(
      appBar: AppBar(title: Text(dt('تأكيد الطلب'))),
      body: loading
          ? ListView(
              padding: const EdgeInsets.all(18),
              children: const [
                DarbSkeletonCard(lines: 3),
                SizedBox(height: 12),
                DarbSkeletonCard(lines: 2),
              ],
            )
          : error != null && addresses.isEmpty
              ? ListView(
                  padding: const EdgeInsets.all(20),
                  children: [
                    _ErrorPanel(message: error!, retry: _load),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: addingAddress ? null : _newAddress,
                      icon: const Icon(Icons.add_location_alt_outlined),
                      label: Text(dt('إضافة عنوان جديد')),
                    ),
                  ],
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        gradient: DarbColors.heroGradient,
                        borderRadius: BorderRadius.circular(DarbRadius.xl),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.receipt_long_rounded,
                            color: DarbColors.lime,
                            size: 27,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  dt('مراجعة طلبك'),
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  dt('راجع المنتجات والعنوان قبل إرسال الطلب'),
                                  style: TextStyle(
                                    color: Colors.white.withValues(alpha: .78),
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),
                    DarbSectionHeader(title: dt('ملخص السلة')),
                    const SizedBox(height: 10),
                    DarbSurfaceCard(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        children: [
                          for (var index = 0;
                              index < widget.items.length;
                              index++) ...[
                            if (index > 0) const Divider(height: 18),
                            Row(
                              children: [
                                Container(
                                  width: 42,
                                  height: 42,
                                  decoration: BoxDecoration(
                                    color: DarbColors.surfaceAlt,
                                    borderRadius: BorderRadius.circular(13),
                                  ),
                                  child: Icon(
                                    Icons.inventory_2_outlined,
                                    color: DarbColors.brandForeground,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        widget.items[index]['name'].toString(),
                                        style: TextStyle(
                                          fontWeight: FontWeight.w800,
                                          fontSize: 13,
                                          color: DarbColors.ink,
                                        ),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        '${dt('الكمية')}: ${widget.items[index]['quantity']}',
                                        style: TextStyle(
                                          color: DarbColors.muted,
                                          fontSize: 11,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Text(
                                  '${widget.items[index]['price']} ${widget.items[index]['currency']}',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    color: DarbColors.brandForeground,
                                  ),
                                ),
                              ],
                            ),
                          ],
                          const Divider(height: 24),
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  quote != null
                                      ? dt('المجموع الفرعي')
                                      : dt('المجموع الفرعي التقريبي'),
                                  style: TextStyle(
                                    color: DarbColors.muted,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              Text(
                                '${quote?['subtotal'] ?? subtotal} ${quote?['currency'] ?? currency}',
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w800,
                                  color: DarbColors.ink,
                                ),
                              ),
                            ],
                          ),
                          if (quoting) ...[
                            const SizedBox(height: 10),
                            const LinearProgressIndicator(minHeight: 2),
                          ] else if (quote != null) ...[
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    quote!['distanceKm'] != null
                                        ? '${dt('رسوم التوصيل')} (${quote!['distanceKm']} ${dt('كم')})'
                                        : dt('رسوم التوصيل'),
                                    style: TextStyle(
                                      color: DarbColors.muted,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                                Text(
                                  '${quote!['deliveryFee']} ${quote!['currency'] ?? currency}',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                    color: DarbColors.ink,
                                  ),
                                ),
                              ],
                            ),
                            const Divider(height: 20),
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    dt('الإجمالي النهائي'),
                                    style: TextStyle(
                                      color: DarbColors.ink,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 15,
                                    ),
                                  ),
                                ),
                                Text(
                                  '${quote!['total']} ${quote!['currency'] ?? currency}',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900,
                                    color: DarbColors.brandForeground,
                                  ),
                                ),
                              ],
                            ),
                          ] else if (quoteError != null) ...[
                            const SizedBox(height: 10),
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: DarbColors.warning.withValues(alpha: .12),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.info_outline_rounded,
                                    color: DarbColors.warning,
                                    size: 18,
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      quoteError!,
                                      style: TextStyle(
                                        color: DarbColors.ink,
                                        fontSize: 11.5,
                                        height: 1.4,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ] else ...[
                            const SizedBox(height: 7),
                            Align(
                              alignment: AlignmentDirectional.centerStart,
                              child: Text(
                                dt('السعر النهائي ورسوم التوصيل يؤكدهما الخادم عند إنشاء الطلب'),
                                style: TextStyle(
                                  color: DarbColors.muted,
                                  fontSize: 10.5,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),
                    DarbSectionHeader(
                      title: dt('عنوان التوصيل'),
                      trailing: TextButton.icon(
                        onPressed:
                            addingAddress || sending ? null : _newAddress,
                        icon: const Icon(Icons.add_location_alt_outlined, size: 17),
                        label: Text(dt('إضافة عنوان')),
                      ),
                    ),
                    const SizedBox(height: 8),
                    DarbSurfaceCard(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (addresses.isEmpty)
                            _EmptyPanel(
                              text: dt('لا يوجد عنوان محفوظ. أضف عنواناً للمتابعة.'),
                            ),
                          if (addresses.isNotEmpty)
                            DropdownButtonFormField<String>(
                              value: addresses.any(
                                (address) =>
                                    address['id']?.toString() == addressId,
                              )
                                  ? addressId
                                  : null,
                              isExpanded: true,
                              dropdownColor: DarbColors.surfaceElevated,
                              decoration: InputDecoration(
                                labelText: dt('اختر عنوان التوصيل'),
                                prefixIcon:
                                    const Icon(Icons.location_on_outlined),
                              ),
                              items: [
                                for (final address in addresses)
                                  DropdownMenuItem(
                                    value: address['id'].toString(),
                                    child: Text(
                                      '${address['label']?.toString().trim().isNotEmpty == true ? address['label'] : dt('عنوان')} — ${address['details'] ?? ''}',
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                              ],
                              onChanged: sending
                                  ? null
                                  : (value) {
                                      setState(() {
                                        addressId = value;
                                        error = null;
                                      });
                                      unawaited(_fetchQuote());
                                    },
                            ),
                          if (addressId != null) ...[
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                Icon(
                                  _selectedAddressHasLocation
                                      ? Icons.check_circle_rounded
                                      : Icons.info_outline_rounded,
                                  size: 17,
                                  color: _selectedAddressHasLocation
                                      ? DarbColors.success
                                      : DarbColors.warning,
                                ),
                                const SizedBox(width: 7),
                                Expanded(
                                  child: Text(
                                    _selectedAddressHasLocation
                                        ? dt('موقع العنوان محفوظ ويمكن حساب المسافة')
                                        : dt('لا توجد إحداثيات لهذا العنوان. قد يطلب النظام تحديد الموقع لحساب رسوم التوصيل.'),
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: _selectedAddressHasLocation
                                          ? DarbColors.success
                                          : DarbColors.warning,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    TextField(
                      controller: notes,
                      maxLength: 500,
                      maxLines: 3,
                      enabled: !sending,
                      decoration: InputDecoration(
                        labelText: dt('ملاحظات للمتجر (اختياري)'),
                        hintText: dt('تعليمات تساعد المتجر في تجهيز طلبك'),
                        prefixIcon: const Icon(Icons.notes_rounded),
                        alignLabelWithHint: true,
                      ),
                    ),
                    if (error != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 12),
                        child: _ErrorPanel(message: error!, retry: _submit),
                      ),
                    const SizedBox(height: 18),
                    FilledButton(
                      onPressed:
                          sending || addressId == null || widget.items.isEmpty
                              ? null
                              : _submit,
                      child: sending
                          ? const SizedBox(
                              width: 21,
                              height: 21,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(
                                  Icons.check_circle_outline_rounded,
                                  size: 19,
                                ),
                                const SizedBox(width: 8),
                                Text(dt('تأكيد الطلب • الدفع عند الاستلام')),
                              ],
                            ),
                    ),
                    const SizedBox(height: 9),
                    Center(
                      child: Text(
                        dt('لن يتم تحصيل أي مبلغ إلكترونياً في هذه الخطوة'),
                        style: TextStyle(color: DarbColors.muted, fontSize: 10.5),
                      ),
                    ),
                  ],
                ),
    );
  }
}

class OrderCreatedScreen extends StatelessWidget {
  final Map<String, dynamic> order;
  const OrderCreatedScreen({super.key, required this.order});

  @override
  Widget build(BuildContext context) {
    final orderNumber =
        order['orderNumber']?.toString() ?? order['id']?.toString() ?? '—';
    final currency = order['currency']?.toString() ?? '';
    final total = order['total']?.toString() ?? '—';
    final deliveryFee = order['deliveryFee']?.toString();
    return Scaffold(
      appBar: AppBar(title: Text(dt('تم استلام طلبك'))),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(22),
          children: [
            const SizedBox(height: 24),
            DarbFadeSlide(
              child: Center(
                child: Container(
                  width: 92,
                  height: 92,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: DarbColors.success.withValues(alpha: .12),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.check_rounded,
                    color: DarbColors.success,
                    size: 52,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 22),
            Text(
              dt('تم إرسال طلبك بنجاح'),
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 23,
                fontWeight: FontWeight.w900,
                color: DarbColors.ink,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              dt('وصل طلبك إلى النظام، ويمكنك متابعة حالته من قسم طلباتي.'),
              textAlign: TextAlign.center,
              style: TextStyle(color: DarbColors.muted, height: 1.5),
            ),
            const SizedBox(height: 24),
            DarbSurfaceCard(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  Text(
                    dt('رقم الطلب'),
                    style: TextStyle(color: DarbColors.muted, fontSize: 12),
                  ),
                  const SizedBox(height: 6),
                  Directionality(
                    textDirection: TextDirection.ltr,
                    child: SelectableText(
                      orderNumber,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                        color: DarbColors.brandForeground,
                      ),
                    ),
                  ),
                  const Divider(height: 28),
                  if (deliveryFee != null)
                    _confirmationValue(
                      context,
                      dt('رسوم التوصيل'),
                      '$deliveryFee $currency',
                    ),
                  _confirmationValue(
                    context,
                    dt('الإجمالي عند الاستلام'),
                    '$total $currency',
                  ),
                  _confirmationValue(
                    context,
                    dt('طريقة الدفع'),
                    dt('الدفع نقداً عند الاستلام'),
                  ),
                  _confirmationValue(
                    context,
                    dt('حالة الطلب'),
                    dt('بانتظار تأكيد المتجر'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: () =>
                  Navigator.of(context).popUntil((route) => route.isFirst),
              icon: const Icon(Icons.home_rounded),
              label: Text(dt('العودة إلى الرئيسية')),
            ),
            const SizedBox(height: 10),
            Text(
              dt('احتفظ برقم الطلب للرجوع إليه عند الحاجة.'),
              textAlign: TextAlign.center,
              style: TextStyle(color: DarbColors.muted, fontSize: 11.5),
            ),
          ],
        ),
      ),
    );
  }

  Widget _confirmationValue(BuildContext context, String label, String value) =>
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(
          children: [
            Expanded(
              child: Text(
                label,
                style: TextStyle(color: DarbColors.muted, fontSize: 12),
              ),
            ),
            Flexible(
              child: Text(
                value,
                textAlign: TextAlign.end,
                style: TextStyle(
                  color: DarbColors.ink,
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
      );
}

class CustomerOrders extends StatelessWidget {
  const CustomerOrders({super.key});
  @override
  Widget build(BuildContext context) => _DataList(
        path: '/orders/mine',
        title: dt('طلباتك'),
        empty: dt('لا توجد طلبات حتى الآن'),
      );
}

class VendorOrders extends StatelessWidget {
  const VendorOrders({super.key});
  @override
  Widget build(BuildContext context) => _DataList(
        path: '/orders/vendor',
        title: dt('طلبات المتجر'),
        empty: dt('لا توجد طلبات واردة'),
      );
}

class VendorProducts extends StatefulWidget {
  const VendorProducts({super.key});
  @override
  State<VendorProducts> createState() => _VendorProductsState();
}

class _VendorProductsState extends State<VendorProducts> {
  final search = TextEditingController();
  bool loading = true, saving = false;
  String? error, vendorStatus;
  Map<String, dynamic>? vendorProfile;
  int _loadGeneration = 0;
  List products = [];

  @override
  void initState() {
    super.initState();
    darbLocale.addListener(_onLocaleChanged);
    search.addListener(_refresh);
    _load();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  void _onLocaleChanged() => _load();

  @override
  void dispose() {
    darbLocale.removeListener(_onLocaleChanged);
    search.removeListener(_refresh);
    search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final generation = ++_loadGeneration;
    if (mounted) setState(() => loading = true);
    try {
      final mine = await Api.instance.get('/vendors/mine');
      if (generation != _loadGeneration) return;
      vendorProfile = mine is Map ? Map<String, dynamic>.from(mine) : null;
      vendorStatus = vendorProfile?['status']?.toString();
      if (vendorStatus != 'APPROVED') {
        products = [];
        error = null;
      } else {
        final loaded = await Api.instance.get(
          '/vendor/products?locale=${darbLocale.value.languageCode}',
        ) as List;
        if (generation != _loadGeneration) return;
        products = loaded;
        error = null;
      }
    } catch (e) {
      if (generation == _loadGeneration) error = e.toString();
    } finally {
      if (mounted && generation == _loadGeneration) {
        setState(() => loading = false);
      }
    }
  }

  Future<void> _add() async {
    final name = TextEditingController();
    final price = TextEditingController();
    final stock = TextEditingController();
    final description = TextEditingController();
    String? dialogError;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: Text(dt('منتج جديد')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: name,
                  decoration: InputDecoration(labelText: dt('اسم المنتج')),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: price,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(labelText: dt('السعر')),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: stock,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: dt('الكمية المتوفرة (اختياري)'),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: description,
                  maxLines: 2,
                  decoration: InputDecoration(labelText: dt('الوصف')),
                ),
                if (dialogError != null) ...[
                  const SizedBox(height: 10),
                  Text(
                    dialogError!,
                    style: TextStyle(color: DarbColors.danger, fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(dt('إلغاء')),
            ),
            FilledButton(
              onPressed: () {
                final parsedPrice = double.tryParse(price.text.trim()) ?? 0;
                final stockText = stock.text.trim();
                final parsedStock =
                    stockText.isEmpty ? null : int.tryParse(stockText);
                if (name.text.trim().isEmpty || parsedPrice <= 0) {
                  setDialogState(
                    () => dialogError = dt('أدخل اسم المنتج وسعراً أكبر من صفر'),
                  );
                  return;
                }
                if (stockText.isNotEmpty &&
                    (parsedStock == null || parsedStock < 0)) {
                  setDialogState(
                    () => dialogError = dt('أدخل كمية صحيحة غير سالبة'),
                  );
                  return;
                }
                Navigator.pop(ctx, true);
              },
              child: Text(dt('إضافة')),
            ),
          ],
        ),
      ),
    );

    if (ok == true &&
        name.text.trim().isNotEmpty &&
        (double.tryParse(price.text.trim()) ?? 0) > 0) {
      final parsedStock = stock.text.trim().isEmpty
          ? null
          : int.tryParse(stock.text.trim());
      setState(() => saving = true);
      try {
        await Api.instance.post('/vendor/products', {
          'name': name.text.trim(),
          'price': double.parse(price.text.trim()),
          'description': description.text.trim(),
          if (parsedStock != null) 'stockQty': parsedStock,
          'currency': 'SYP',
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(dt('تمت إضافة المنتج بنجاح'))),
          );
        }
        await _load();
      } catch (e) {
        if (mounted) setState(() => error = e.toString());
      } finally {
        if (mounted) setState(() => saving = false);
      }
    }
    name.dispose();
    price.dispose();
    stock.dispose();
    description.dispose();
  }

  Future<void> _editProduct(dynamic product) async {
    final name = TextEditingController(text: _productName(product));
    final price = TextEditingController(
      text: product['basePrice']?.toString() ?? '',
    );
    final stock = TextEditingController(
      text: product['stockQty']?.toString() ?? '',
    );
    final description = TextEditingController(
      text: _localizedCatalogDescription(product),
    );
    bool isAvailable = product['isAvailable'] != false;
    String? dialogError;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: Text(dt('تعديل المنتج')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: name,
                  decoration: InputDecoration(labelText: dt('اسم المنتج')),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: price,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(labelText: dt('السعر')),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: stock,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: dt('الكمية المتوفرة (اختياري)'),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: description,
                  maxLines: 2,
                  decoration: InputDecoration(labelText: dt('الوصف')),
                ),
                const SizedBox(height: 6),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(dt('متاح للطلب')),
                  value: isAvailable,
                  onChanged: (value) =>
                      setDialogState(() => isAvailable = value),
                ),
                if (dialogError != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    dialogError!,
                    style: TextStyle(color: DarbColors.danger, fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(dt('إلغاء')),
            ),
            FilledButton(
              onPressed: () {
                final parsedPrice = double.tryParse(price.text.trim()) ?? 0;
                final stockText = stock.text.trim();
                final parsedStock =
                    stockText.isEmpty ? null : int.tryParse(stockText);
                if (name.text.trim().isEmpty || parsedPrice <= 0) {
                  setDialogState(
                    () => dialogError = dt('أدخل اسم المنتج وسعراً أكبر من صفر'),
                  );
                  return;
                }
                if (stockText.isNotEmpty &&
                    (parsedStock == null || parsedStock < 0)) {
                  setDialogState(
                    () => dialogError = dt('أدخل كمية صحيحة غير سالبة'),
                  );
                  return;
                }
                Navigator.pop(ctx, true);
              },
              child: Text(dt('حفظ التغييرات')),
            ),
          ],
        ),
      ),
    );

    if (ok == true) {
      setState(() => saving = true);
      try {
        final stockText = stock.text.trim();
        await Api.instance.patch('/vendor/products/${product['id']}', {
          'name': name.text.trim(),
          'price': double.parse(price.text.trim()),
          'description': description.text.trim(),
          'isAvailable': isAvailable,
          'stockQty': stockText.isEmpty ? null : int.parse(stockText),
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(dt('تم تحديث المنتج بنجاح'))),
          );
        }
        await _load();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(e.toString())),
          );
        }
      } finally {
        if (mounted) setState(() => saving = false);
      }
    }
    name.dispose();
    price.dispose();
    stock.dispose();
    description.dispose();
  }

  Future<void> _toggleAvailability(dynamic product, bool value) async {
    setState(() => saving = true);
    try {
      await Api.instance.patch('/vendor/products/${product['id']}', {
        'isAvailable': value,
      });
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString())),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> _editStoreProfile() async {
    final profile = vendorProfile;
    if (profile == null) return;
    final translations = (profile['translations'] as List?) ?? const [];
    final firstTrans =
        translations.isNotEmpty && translations.first is Map ? translations.first as Map : const {};
    final location = profile['location'] as Map?;
    final name = TextEditingController(
      text: firstTrans['name']?.toString() ?? '',
    );
    final type = TextEditingController(
      text: profile['type']?.toString() ?? '',
    );
    final description = TextEditingController(
      text: firstTrans['description']?.toString() ?? '',
    );
    final address = TextEditingController(
      text: location?['address']?.toString() ?? '',
    );
    double? latitude;
    double? longitude;
    bool locating = false;
    String? dialogError;
    final hasSavedLocation = location?['hasLocation'] == true;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialog) => AlertDialog(
          title: Text(dt('إعدادات المتجر')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: name,
                  decoration: InputDecoration(labelText: dt('اسم المتجر')),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: type,
                  decoration: InputDecoration(labelText: dt('نوع النشاط')),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: description,
                  maxLines: 2,
                  decoration: InputDecoration(labelText: dt('الوصف')),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: address,
                  decoration:
                      InputDecoration(labelText: dt('عنوان المتجر (اختياري)')),
                ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: locating
                      ? null
                      : () async {
                          setDialog(() {
                            locating = true;
                            dialogError = null;
                          });
                          try {
                            if (!await Geolocator.isLocationServiceEnabled()) {
                              throw Exception(
                                dt('فعّل خدمة الموقع في هاتفك أولاً'),
                              );
                            }
                            var permission = await Geolocator.checkPermission();
                            if (permission == LocationPermission.denied) {
                              permission =
                                  await Geolocator.requestPermission();
                            }
                            if (permission == LocationPermission.denied ||
                                permission ==
                                    LocationPermission.deniedForever) {
                              throw Exception(
                                dt('يلزم السماح للتطبيق بالوصول إلى موقعك'),
                              );
                            }
                            final point = await Geolocator.getCurrentPosition(
                              locationSettings: const LocationSettings(
                                accuracy: LocationAccuracy.high,
                                timeLimit: Duration(seconds: 20),
                              ),
                            );
                            latitude = point.latitude;
                            longitude = point.longitude;
                          } catch (e) {
                            dialogError = e.toString();
                          } finally {
                            if (ctx.mounted) {
                              setDialog(() => locating = false);
                            }
                          }
                        },
                  icon: locating
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Icon(
                          latitude != null || hasSavedLocation
                              ? Icons.check_circle_rounded
                              : Icons.my_location_rounded,
                        ),
                  label: Text(
                    locating
                        ? dt('جارٍ تحديد الموقع...')
                        : latitude != null
                            ? dt('تم تحديث موقع المتجر')
                            : hasSavedLocation
                                ? dt('تحديث موقع المتجر الحالي')
                                : dt('تحديد موقع المتجر'),
                  ),
                ),
                if (dialogError != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    dialogError!,
                    style: TextStyle(color: DarbColors.danger, fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: locating ? null : () => Navigator.pop(ctx, false),
              child: Text(dt('إلغاء')),
            ),
            FilledButton(
              onPressed: locating
                  ? null
                  : () {
                      if (name.text.trim().isEmpty || type.text.trim().isEmpty) {
                        setDialog(
                          () => dialogError = dt('أدخل اسم المتجر ونوع النشاط'),
                        );
                        return;
                      }
                      Navigator.pop(ctx, true);
                    },
              child: Text(dt('حفظ التغييرات')),
            ),
          ],
        ),
      ),
    );

    if (ok == true) {
      setState(() => saving = true);
      try {
        await Api.instance.patch('/vendors/mine', {
          'name': name.text.trim(),
          'type': type.text.trim(),
          'description': description.text.trim(),
          'address': address.text.trim(),
          if (latitude != null && longitude != null) 'latitude': latitude,
          if (latitude != null && longitude != null) 'longitude': longitude,
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(dt('تم تحديث بيانات المتجر بنجاح'))),
          );
        }
        await _load();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(e.toString())),
          );
        }
      } finally {
        if (mounted) setState(() => saving = false);
      }
    }
    name.dispose();
    type.dispose();
    description.dispose();
    address.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = search.text.trim().toLowerCase();
    final visible = products
        .where((p) => _productName(p).toLowerCase().contains(query))
        .toList();
    final hasStoreGps = vendorProfile?['location']?['hasLocation'] == true;

    return Scaffold(
      floatingActionButton: vendorStatus == 'APPROVED'
          ? FloatingActionButton.extended(
              onPressed: saving ? null : _add,
              icon: const Icon(Icons.add),
              label: Text(dt('إضافة منتج')),
            )
          : null,
      body: loading
          ? ListView(
              padding: const EdgeInsets.all(18),
              children: List.generate(
                3,
                (_) => const Padding(
                  padding: EdgeInsets.only(bottom: 10),
                  child: DarbSkeletonCard(lines: 2),
                ),
              ),
            )
          : vendorStatus != null && vendorStatus != 'APPROVED'
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: DarbSurfaceCard(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          DarbStatusBadge(
                            label: vendorStatus == 'PENDING'
                                ? dt('قيد المراجعة')
                                : vendorStatus == 'REJECTED'
                                    ? dt('مرفوض')
                                    : dt('معلّق'),
                            tone: vendorStatus == 'PENDING'
                                ? DarbTone.warning
                                : DarbTone.danger,
                          ),
                          const SizedBox(height: 12),
                          Text(
                            vendorStatus == 'PENDING'
                                ? dt('طلب متجرك قيد المراجعة. ستتمكن من إدارة المنتجات بعد اعتماد الإدارة.')
                                : dt('حالة المتجر: $vendorStatus'),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: DarbColors.ink,
                              height: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              : error != null
                  ? ListView(
                      padding: const EdgeInsets.all(18),
                      children: [_ErrorPanel(message: error!, retry: _load)],
                    )
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(18, 16, 18, 92),
                        children: [
                          Container(
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              gradient: DarbColors.heroGradient,
                              borderRadius: BorderRadius.circular(DarbRadius.xl),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.inventory_2_rounded,
                                      color: DarbColors.lime,
                                      size: 26,
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Text(
                                        dt('منتجات متجرك'),
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 19,
                                          fontWeight: FontWeight.w900,
                                        ),
                                      ),
                                    ),
                                    DarbStatusBadge(
                                      label:
                                          '${dt('إجمالي المنتجات')}: ${products.length}',
                                      tone: DarbTone.brand,
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: [
                                    DarbStatusBadge(
                                      label: hasStoreGps
                                          ? dt('موقع المتجر محدد')
                                          : dt('موقع المتجر غير محدد'),
                                      tone: hasStoreGps
                                          ? DarbTone.success
                                          : DarbTone.warning,
                                    ),
                                    ActionChip(
                                      avatar: Icon(
                                        Icons.storefront_outlined,
                                        size: 16,
                                        color: DarbColors.forest,
                                      ),
                                      label: Text(
                                        dt('إعدادات المتجر'),
                                        style: TextStyle(
                                          color: DarbColors.forest,
                                          fontWeight: FontWeight.w800,
                                        ),
                                      ),
                                      backgroundColor: DarbColors.lime,
                                      side: BorderSide.none,
                                      onPressed:
                                          saving ? null : _editStoreProfile,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                          if (products.isNotEmpty) ...[
                            TextField(
                              controller: search,
                              textInputAction: TextInputAction.search,
                              decoration: InputDecoration(
                                hintText: dt('ابحث في منتجاتك...'),
                                prefixIcon: const Icon(Icons.search_rounded),
                                suffixIcon: search.text.isEmpty
                                    ? null
                                    : IconButton(
                                        onPressed: search.clear,
                                        icon: const Icon(Icons.close_rounded),
                                      ),
                              ),
                            ),
                            const SizedBox(height: 12),
                          ],
                          if (products.isEmpty)
                            _EmptyPanel(text: dt('لم تضف أي منتجات بعد'))
                          else if (visible.isEmpty)
                            _EmptyPanel(text: dt('لم نعثر على منتجات مطابقة'))
                          else
                            for (var i = 0; i < visible.length; i++)
                              DarbFadeSlide(
                                delay: DarbMotion.cappedStaggerDelay(i),
                                child: Padding(
                                  padding: const EdgeInsets.only(bottom: 10),
                                  child: DarbSurfaceCard(
                                    padding: const EdgeInsets.all(14),
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 48,
                                          height: 48,
                                          decoration: BoxDecoration(
                                            color: DarbColors.surfaceAlt,
                                            borderRadius:
                                                BorderRadius.circular(14),
                                          ),
                                          child: Icon(
                                            Icons.inventory_2_outlined,
                                            color: DarbColors.brandForeground,
                                          ),
                                        ),
                                        const SizedBox(width: 12),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                _productName(visible[i]),
                                                style: TextStyle(
                                                  color: DarbColors.ink,
                                                  fontWeight: FontWeight.w900,
                                                  fontSize: 14,
                                                ),
                                              ),
                                              if (_localizedCatalogDescription(
                                                      visible[i])
                                                  .isNotEmpty) ...[
                                                const SizedBox(height: 3),
                                                Text(
                                                  _localizedCatalogDescription(
                                                      visible[i]),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                    color: DarbColors.muted,
                                                    fontSize: 11.5,
                                                  ),
                                                ),
                                              ],
                                              const SizedBox(height: 5),
                                              Wrap(
                                                spacing: 8,
                                                runSpacing: 4,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.center,
                                                children: [
                                                  Text(
                                                    '${visible[i]['basePrice']} ${visible[i]['currency']}',
                                                    style: TextStyle(
                                                      color: DarbColors
                                                          .brandForeground,
                                                      fontWeight:
                                                          FontWeight.w800,
                                                      fontSize: 12.5,
                                                    ),
                                                  ),
                                                  if (visible[i]['stockQty'] !=
                                                      null)
                                                    DarbStatusBadge(
                                                      label:
                                                          '${dt('المخزون')}: ${visible[i]['stockQty']}',
                                                      tone: DarbTone.info,
                                                    ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: [
                                            Switch.adaptive(
                                              value:
                                                  visible[i]['isAvailable'] !=
                                                      false,
                                              onChanged: saving
                                                  ? null
                                                  : (val) =>
                                                      _toggleAvailability(
                                                        visible[i],
                                                        val,
                                                      ),
                                            ),
                                            IconButton(
                                              tooltip: dt('تعديل'),
                                              onPressed: saving
                                                  ? null
                                                  : () =>
                                                      _editProduct(visible[i]),
                                              icon: const Icon(
                                                Icons.edit_outlined,
                                                size: 19,
                                              ),
                                              constraints:
                                                  const BoxConstraints.tightFor(
                                                width: 34,
                                                height: 34,
                                              ),
                                              padding: EdgeInsets.zero,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                        ],
                      ),
                    ),
    );
  }
}
