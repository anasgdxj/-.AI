import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Shared visual language for DARB PULSE 2026.
/// Keep product screens on these tokens for consistent light/dark & RTL/LTR behavior.
abstract final class DarbColors {
  static bool get _dark => DarbTheme.brightness.value == Brightness.dark;

  // Brand anchors remain stable; semantic surfaces and foregrounds adapt.
  static Color get forest => const Color(0xFF102B26);
  static Color get forestSoft => const Color(0xFF1C443B);
  static Color get forestDeep => const Color(0xFF0A1D19);
  static Color get mint => const Color(0xFFB9E4D2);
  static Color get lime => const Color(0xFFC8F169);

  static Color get canvas =>
      _dark ? const Color(0xFF0B1512) : const Color(0xFFF5F6F2);
  static Color get surface =>
      _dark ? const Color(0xFF13221D) : const Color(0xFFFFFFFF);
  static Color get surfaceElevated =>
      _dark ? const Color(0xFF182B24) : const Color(0xFFFFFFFF);
  static Color get surfaceAlt =>
      _dark ? const Color(0xFF1A2D26) : const Color(0xFFEAF2EC);
  static Color get surfaceMuted =>
      _dark ? const Color(0xFF14241E) : const Color(0xFFF0F3EE);

  static Color get onForest => const Color(0xFFFFFFFF);
  static Color get brandForeground => _dark ? mint : forest;
  static Color get pillBg =>
      _dark ? const Color(0xFF1B3A30) : const Color(0xFFE3F4EC);
  static Color get pillFg => _dark ? mint : forest;

  static Color get ink =>
      _dark ? const Color(0xFFF1F5F1) : const Color(0xFF17231F);
  static Color get muted =>
      _dark ? const Color(0xFFA4B2AA) : const Color(0xFF77837D);
  static Color get line =>
      _dark ? const Color(0xFF2A3B33) : const Color(0xFFE4E9E3);
  static Color get borderStrong =>
      _dark ? const Color(0xFF40564A) : const Color(0xFFCBD5CE);

  static Color get danger =>
      _dark ? const Color(0xFFE47777) : const Color(0xFFB94747);
  static Color get success =>
      _dark ? const Color(0xFF75C99A) : const Color(0xFF287A50);
  static Color get warning =>
      _dark ? const Color(0xFFE5B968) : const Color(0xFFB7791F);
  static Color get info =>
      _dark ? const Color(0xFF83B8E0) : const Color(0xFF356D9A);
  static Color get scrim =>
      _dark ? const Color(0xB8000000) : const Color(0x990B1713);

  static Color get shimmerBase =>
      _dark ? const Color(0xFF192B24) : const Color(0xFFE7ECE7);
  static Color get shimmerHighlight =>
      _dark ? const Color(0xFF253D34) : const Color(0xFFF6F9F6);

  static LinearGradient get heroGradient => LinearGradient(
        begin: AlignmentDirectional.topEnd,
        end: AlignmentDirectional.bottomStart,
        colors: _dark
            ? const [Color(0xFF183B31), Color(0xFF0E2620), Color(0xFF081613)]
            : const [Color(0xFF285647), Color(0xFF102B26), Color(0xFF091D19)],
      );
}

abstract final class DarbSpace {
  static const double xxs = 4, xs = 8, sm = 12, md = 16, lg = 20;
  static const double xl = 24, xxl = 32, section = 40;
}

abstract final class DarbRadius {
  static const double sm = 12, md = 16, lg = 22, xl = 28;
  static const double hero = 36, pill = 999;
}

abstract final class DarbMotion {
  static const Duration press = Duration(milliseconds: 120);
  static const Duration fast = Duration(milliseconds: 160);
  static const Duration standard = Duration(milliseconds: 260);
  static const Duration route = Duration(milliseconds: 340);
  static const Duration expressive = Duration(milliseconds: 420);
  static const Duration staggerStep = Duration(milliseconds: 55);
  static const Duration shimmer = Duration(milliseconds: 1300);
  static const Duration pulse = Duration(milliseconds: 1400);

  static const Curve enter = Curves.easeOutCubic;
  static const Curve exit = Curves.easeInCubic;
  static const Curve pressCurve = Curves.easeOutCubic;
  static const Curve expressiveCurve = Curves.easeOutBack;
  static const Curve spring = Curves.easeOutQuart;

  /// Honors Android/iOS accessibility settings for reduced motion.
  static bool reduceMotion(BuildContext context) =>
      MediaQuery.maybeOf(context)?.disableAnimations ?? false;

  static Duration effectiveDuration(
    BuildContext context,
    Duration duration,
  ) =>
      reduceMotion(context) ? Duration.zero : duration;

  static Duration staggerDelay(int index) {
    if (index <= 0) return Duration.zero;
    return Duration(milliseconds: staggerStep.inMilliseconds * index);
  }

  /// Caps staggered entrances on long lists so items never stall waiting.
  static Duration cappedStaggerDelay(int index, {int maxIndex = 8}) {
    if (index <= 0) return Duration.zero;
    final clamped = index > maxIndex ? maxIndex : index;
    return Duration(milliseconds: staggerStep.inMilliseconds * clamped);
  }

  static bool isRtl(BuildContext context) =>
      Directionality.maybeOf(context) == TextDirection.rtl;

  /// Returns an entrance offset adapted to the active text direction.
  static Offset directionalOffset(
    BuildContext context, {
    double dx = 0.08,
    double dy = 0,
  }) =>
      Offset(isRtl(context) ? -dx : dx, dy);
}

/// Direction-aware icon helpers so RTL/LTR arrows never point backwards.
abstract final class DarbIcons {
  static IconData chevronForward(BuildContext context) =>
      DarbMotion.isRtl(context)
          ? Icons.chevron_left_rounded
          : Icons.chevron_right_rounded;

  static IconData arrowForward(BuildContext context) =>
      DarbMotion.isRtl(context)
          ? Icons.arrow_back_rounded
          : Icons.arrow_forward_rounded;

  static IconData arrowBack(BuildContext context) =>
      DarbMotion.isRtl(context)
          ? Icons.arrow_forward_rounded
          : Icons.arrow_back_rounded;
}

/// One route transition shared by light and dark themes.
/// It remains short and never blocks navigation when reduced motion is enabled.
class DarbPageTransitionsBuilder extends PageTransitionsBuilder {
  const DarbPageTransitionsBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    if (DarbMotion.reduceMotion(context)) return child;

    final progress = CurvedAnimation(
      parent: animation,
      curve: DarbMotion.enter,
      reverseCurve: DarbMotion.exit,
    );
    return FadeTransition(
      opacity: progress,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, .035),
          end: Offset.zero,
        ).animate(progress),
        child: ScaleTransition(
          scale: Tween<double>(begin: .985, end: 1).animate(progress),
          child: child,
        ),
      ),
    );
  }
}

/// Reusable entrance motion for content blocks and list items.
/// The optional delay enables a controlled stagger without extra packages.
class DarbFadeSlide extends StatefulWidget {
  const DarbFadeSlide({
    super.key,
    required this.child,
    this.duration = DarbMotion.standard,
    this.delay = Duration.zero,
    this.offset = const Offset(0, .10),
    this.curve = DarbMotion.enter,
  });

  final Widget child;
  final Duration duration;
  final Duration delay;
  final Offset offset;
  final Curve curve;

  @override
  State<DarbFadeSlide> createState() => _DarbFadeSlideState();
}

class _DarbFadeSlideState extends State<DarbFadeSlide>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  Timer? _delayTimer;
  bool _hasScheduled = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: widget.duration,
      value: 0,
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (DarbMotion.reduceMotion(context)) {
      _delayTimer?.cancel();
      _hasScheduled = true;
      _controller.value = 1;
      return;
    }
    if (_hasScheduled) return;
    _hasScheduled = true;
    _controller.value = 0;
    if (widget.delay == Duration.zero) {
      _controller.forward();
    } else {
      _delayTimer = Timer(widget.delay, () {
        if (mounted) _controller.forward();
      });
    }
  }

  @override
  void didUpdateWidget(covariant DarbFadeSlide oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.duration != widget.duration) {
      _controller.duration = widget.duration;
    }
  }

  @override
  void dispose() {
    _delayTimer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final animation = CurvedAnimation(
      parent: _controller,
      curve: widget.curve,
    );
    return FadeTransition(
      opacity: animation,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: widget.offset,
          end: Offset.zero,
        ).animate(animation),
        child: widget.child,
      ),
    );
  }
}

/// Adds tactile press feedback while respecting reduced-motion settings.
class DarbPressScale extends StatefulWidget {
  const DarbPressScale({
    super.key,
    required this.child,
    this.onTap,
    this.pressedScale = .97,
    this.behavior = HitTestBehavior.opaque,
    this.enableHaptics = false,
  });

  final Widget child;
  final VoidCallback? onTap;
  final double pressedScale;
  final HitTestBehavior behavior;
  final bool enableHaptics;

  @override
  State<DarbPressScale> createState() => _DarbPressScaleState();
}

class _DarbPressScaleState extends State<DarbPressScale> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (!mounted || _pressed == value) return;
    setState(() => _pressed = value);
  }

  void _handleTap() {
    if (widget.enableHaptics) {
      HapticFeedback.selectionClick();
    }
    widget.onTap?.call();
  }

  @override
  Widget build(BuildContext context) {
    final reduceMotion = DarbMotion.reduceMotion(context);
    return AnimatedScale(
      scale: _pressed && !reduceMotion ? widget.pressedScale : 1,
      duration: DarbMotion.effectiveDuration(context, DarbMotion.press),
      curve: DarbMotion.pressCurve,
      child: GestureDetector(
        behavior: widget.behavior,
        onTapDown: widget.onTap == null ? null : (_) => _setPressed(true),
        onTapUp: widget.onTap == null ? null : (_) => _setPressed(false),
        onTapCancel: widget.onTap == null ? null : () => _setPressed(false),
        onTap: widget.onTap == null ? null : _handleTap,
        child: widget.child,
      ),
    );
  }
}

enum DarbTone { brand, success, warning, danger, info, neutral }

/// Live pulsing dot indicator for active orders or online drivers.
/// Automatically halts its ticker when reduced motion is enabled.
class DarbPulseDot extends StatefulWidget {
  const DarbPulseDot({
    super.key,
    this.color,
    this.size = 8,
    this.animate = true,
  });

  final Color? color;
  final double size;
  final bool animate;

  @override
  State<DarbPulseDot> createState() => _DarbPulseDotState();
}

class _DarbPulseDotState extends State<DarbPulseDot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: DarbMotion.pulse,
    );
  }

  void _syncAnimation(BuildContext context) {
    final shouldAnimate = widget.animate && !DarbMotion.reduceMotion(context);
    if (shouldAnimate) {
      if (!_controller.isAnimating) {
        _controller.repeat(reverse: true);
      }
    } else {
      if (_controller.isAnimating) _controller.stop();
      _controller.value = 0;
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _syncAnimation(context);
  }

  @override
  void didUpdateWidget(covariant DarbPulseDot oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.animate != widget.animate) {
      _syncAnimation(context);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dotColor = widget.color ?? DarbColors.success;
    final haloMax = widget.size * 2.1;
    if (!widget.animate || DarbMotion.reduceMotion(context)) {
      return SizedBox(
        width: haloMax,
        height: haloMax,
        child: Center(
          child: Container(
            width: widget.size,
            height: widget.size,
            decoration: BoxDecoration(color: dotColor, shape: BoxShape.circle),
          ),
        ),
      );
    }

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final t = Curves.easeInOut.transform(_controller.value);
        final haloSize = widget.size + (haloMax - widget.size) * t;
        return SizedBox(
          width: haloMax,
          height: haloMax,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: haloSize,
                height: haloSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: dotColor.withValues(alpha: .28 * (1 - t * .7)),
                ),
              ),
              Container(
                width: widget.size,
                height: widget.size,
                decoration: BoxDecoration(
                  color: dotColor,
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Adaptive semantic pill/status badge with consistent light/dark contrast.
class DarbStatusBadge extends StatelessWidget {
  const DarbStatusBadge({
    super.key,
    required this.label,
    this.tone = DarbTone.brand,
    this.icon,
    this.pulse = false,
    this.compact = false,
  });

  final String label;
  final DarbTone tone;
  final IconData? icon;
  final bool pulse;
  final bool compact;

  Color _toneColor() => switch (tone) {
        DarbTone.brand => DarbColors.brandForeground,
        DarbTone.success => DarbColors.success,
        DarbTone.warning => DarbColors.warning,
        DarbTone.danger => DarbColors.danger,
        DarbTone.info => DarbColors.info,
        DarbTone.neutral => DarbColors.muted,
      };

  @override
  Widget build(BuildContext context) {
    final color = _toneColor();
    return Container(
      padding: EdgeInsetsDirectional.symmetric(
        horizontal: compact ? DarbSpace.xs : DarbSpace.sm,
        vertical: compact ? 4 : 6,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .13),
        borderRadius: BorderRadius.circular(DarbRadius.pill),
        border: Border.all(color: color.withValues(alpha: .24)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (pulse) ...[
            DarbPulseDot(color: color, size: compact ? 6 : 7),
            const SizedBox(width: 4),
          ] else if (icon != null) ...[
            Icon(icon, size: compact ? 13 : 14, color: color),
            const SizedBox(width: 5),
          ],
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: color,
                fontSize: compact ? 10.5 : 11.5,
                fontWeight: FontWeight.w800,
                height: 1.15,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Lightweight shimmer placeholder respecting Reduced Motion.
class DarbSkeleton extends StatefulWidget {
  const DarbSkeleton({
    super.key,
    this.width,
    this.height = 16,
    this.borderRadius = DarbRadius.sm,
  });

  final double? width;
  final double height;
  final double borderRadius;

  @override
  State<DarbSkeleton> createState() => _DarbSkeletonState();
}

class _DarbSkeletonState extends State<DarbSkeleton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: DarbMotion.shimmer,
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (DarbMotion.reduceMotion(context)) {
      if (_controller.isAnimating) _controller.stop();
      _controller.value = .35;
    } else if (!_controller.isAnimating) {
      _controller.repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final base = DarbColors.shimmerBase;
    final highlight = DarbColors.shimmerHighlight;
    if (DarbMotion.reduceMotion(context)) {
      return Container(
        width: widget.width,
        height: widget.height,
        decoration: BoxDecoration(
          color: base,
          borderRadius: BorderRadius.circular(widget.borderRadius),
        ),
      );
    }

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final t = Curves.easeInOut.transform(_controller.value);
        return Container(
          width: widget.width,
          height: widget.height,
          decoration: BoxDecoration(
            color: Color.lerp(base, highlight, t),
            borderRadius: BorderRadius.circular(widget.borderRadius),
          ),
        );
      },
    );
  }
}

/// Pre-composed skeleton matching DARB store & order cards.
class DarbSkeletonCard extends StatelessWidget {
  const DarbSkeletonCard({
    super.key,
    this.showLeading = true,
    this.lines = 2,
    this.padding = const EdgeInsetsDirectional.all(DarbSpace.md),
  });

  final bool showLeading;
  final int lines;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: DarbColors.surface,
        borderRadius: BorderRadius.circular(DarbRadius.lg),
        border: Border.all(color: DarbColors.line),
      ),
      child: Row(
        children: [
          if (showLeading) ...[
            const DarbSkeleton(
              width: 52,
              height: 52,
              borderRadius: DarbRadius.md,
            ),
            const SizedBox(width: DarbSpace.sm),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const DarbSkeleton(width: 150, height: 14),
                for (var i = 1; i < lines; i++) ...[
                  const SizedBox(height: DarbSpace.xs),
                  DarbSkeleton(width: i == 1 ? 210 : 120, height: 11),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Unified interactive surface card with optional press feedback & elevation.
class DarbSurfaceCard extends StatelessWidget {
  const DarbSurfaceCard({
    super.key,
    required this.child,
    this.onTap,
    this.padding = const EdgeInsetsDirectional.all(DarbSpace.md),
    this.borderRadius = DarbRadius.lg,
    this.backgroundColor,
    this.borderColor,
    this.elevated = false,
    this.enableHaptics = false,
  });

  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry padding;
  final double borderRadius;
  final Color? backgroundColor;
  final Color? borderColor;
  final bool elevated;
  final bool enableHaptics;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final box = Container(
      decoration: BoxDecoration(
        color: backgroundColor ?? DarbColors.surface,
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(color: borderColor ?? DarbColors.line),
        boxShadow: isDark
            ? const []
            : (elevated ? DarbElevation.floating : DarbElevation.card),
      ),
      child: Material(
        type: MaterialType.transparency,
        borderRadius: BorderRadius.circular(borderRadius),
        clipBehavior: Clip.antiAlias,
        child: onTap == null
            ? Padding(padding: padding, child: child)
            : InkWell(
                onTap: () {
                  if (enableHaptics) {
                    HapticFeedback.selectionClick();
                  }
                  onTap?.call();
                },
                borderRadius: BorderRadius.circular(borderRadius),
                child: Padding(padding: padding, child: child),
              ),
      ),
    );

    if (onTap == null) return box;
    return _DarbPointerScale(child: box);
  }
}

class _DarbPointerScale extends StatefulWidget {
  const _DarbPointerScale({required this.child});
  final Widget child;

  @override
  State<_DarbPointerScale> createState() => _DarbPointerScaleState();
}

class _DarbPointerScaleState extends State<_DarbPointerScale> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (!mounted || _pressed == value) return;
    setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    final reduce = DarbMotion.reduceMotion(context);
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: (_) => _setPressed(true),
      onPointerUp: (_) => _setPressed(false),
      onPointerCancel: (_) => _setPressed(false),
      child: AnimatedScale(
        scale: _pressed && !reduce ? 0.975 : 1,
        duration: DarbMotion.effectiveDuration(context, DarbMotion.press),
        curve: DarbMotion.pressCurve,
        child: widget.child,
      ),
    );
  }
}

/// Direction-aware animated progress bar for multi-step flows & timelines.
class DarbStepProgress extends StatelessWidget {
  const DarbStepProgress({
    super.key,
    required this.totalSteps,
    required this.currentStep,
    this.activeColor,
    this.trackColor,
    this.height = 6,
  });

  final int totalSteps;
  final int currentStep;
  final Color? activeColor;
  final Color? trackColor;
  final double height;

  @override
  Widget build(BuildContext context) {
    final count = totalSteps < 1 ? 1 : totalSteps;
    final active = activeColor ?? DarbColors.brandForeground;
    final track = trackColor ?? DarbColors.line;
    final duration = DarbMotion.effectiveDuration(context, DarbMotion.standard);
    return Row(
      children: [
        for (var i = 0; i < count; i++) ...[
          if (i > 0) const SizedBox(width: 6),
          Expanded(
            child: AnimatedContainer(
              duration: duration,
              curve: DarbMotion.enter,
              height: height,
              decoration: BoxDecoration(
                color: i <= currentStep ? active : track,
                borderRadius: BorderRadius.circular(DarbRadius.pill),
              ),
            ),
          ),
        ],
      ],
    );
  }
}

/// Editorial section heading supporting optional trailing action & RTL/LTR.
class DarbSectionHeader extends StatelessWidget {
  const DarbSectionHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.trailing,
  });

  final String title;
  final String? subtitle;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                textAlign: TextAlign.start,
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w900,
                  color: DarbColors.ink,
                  height: 1.2,
                ),
              ),
              if (subtitle != null && subtitle!.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(
                  subtitle!,
                  textAlign: TextAlign.start,
                  style: TextStyle(
                    fontSize: 12.5,
                    color: DarbColors.muted,
                    height: 1.45,
                  ),
                ),
              ],
            ],
          ),
        ),
        if (trailing != null) ...[
          const SizedBox(width: DarbSpace.sm),
          trailing!,
        ],
      ],
    );
  }
}

abstract final class DarbElevation {
  static const card = <BoxShadow>[
    BoxShadow(color: Color(0x080F2B24), blurRadius: 18, offset: Offset(0, 6)),
  ];
  static const floating = <BoxShadow>[
    BoxShadow(color: Color(0x160F2B24), blurRadius: 28, offset: Offset(0, 12)),
  ];
  static const subtle = <BoxShadow>[
    BoxShadow(color: Color(0x050F2B24), blurRadius: 10, offset: Offset(0, 3)),
  ];

  static List<BoxShadow> cardFor(Brightness brightness) =>
      brightness == Brightness.dark ? const [] : card;
}

abstract final class DarbTheme {
  static const _storage = FlutterSecureStorage();
  static const _modeKey = 'darb_theme_mode';
  static final ValueNotifier<ThemeMode> mode = ValueNotifier(ThemeMode.system);
  static final ValueNotifier<Brightness> brightness =
      ValueNotifier(Brightness.light);

  static void updateBrightness(Brightness value) {
    if (brightness.value != value) brightness.value = value;
  }

  static Future<void> restoreMode() async {
    try {
      final saved = await _storage.read(key: _modeKey);
      mode.value = switch (saved) {
        'light' => ThemeMode.light,
        'dark' => ThemeMode.dark,
        _ => ThemeMode.system,
      };
    } catch (_) {
      mode.value = ThemeMode.system;
    }
  }

  static Future<void> setMode(ThemeMode value) async {
    mode.value = value;
    try {
      final saved = switch (value) {
        ThemeMode.light => 'light',
        ThemeMode.dark => 'dark',
        ThemeMode.system => 'system',
      };
      await _storage.write(key: _modeKey, value: saved);
    } catch (_) {
      // Keep the in-memory selection active if secure storage is unavailable.
    }
  }

  static const PageTransitionsTheme _pageTransitionsTheme = PageTransitionsTheme(
    builders: {
      TargetPlatform.android: DarbPageTransitionsBuilder(),
      TargetPlatform.fuchsia: DarbPageTransitionsBuilder(),
      TargetPlatform.iOS: DarbPageTransitionsBuilder(),
      TargetPlatform.linux: DarbPageTransitionsBuilder(),
      TargetPlatform.macOS: DarbPageTransitionsBuilder(),
      TargetPlatform.windows: DarbPageTransitionsBuilder(),
    },
  );

  static ThemeData get dark {
    const scheme = ColorScheme(
      brightness: Brightness.dark,
      primary: Color(0xFFB9E4D2),
      onPrimary: Color(0xFF102B26),
      secondary: Color(0xFFC8F169),
      onSecondary: Color(0xFF102B26),
      error: Color(0xFFE47777),
      onError: Color(0xFF2A1010),
      surface: Color(0xFF13221D),
      onSurface: Color(0xFFF1F5F1),
    );
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: const Color(0xFF0B1512),
      canvasColor: const Color(0xFF13221D),
      cardColor: const Color(0xFF13221D),
      fontFamily: 'Arial',
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          color: Color(0xFFF1F5F1),
          fontSize: 28,
          fontWeight: FontWeight.w900,
          height: 1.2,
        ),
        headlineMedium: TextStyle(
          color: Color(0xFFF1F5F1),
          fontSize: 23,
          fontWeight: FontWeight.w900,
          height: 1.25,
        ),
        titleLarge: TextStyle(
          color: Color(0xFFF1F5F1),
          fontSize: 19,
          fontWeight: FontWeight.w800,
        ),
        titleMedium: TextStyle(
          color: Color(0xFFF1F5F1),
          fontSize: 15,
          fontWeight: FontWeight.w700,
        ),
        bodyLarge: TextStyle(
          color: Color(0xFFF1F5F1),
          fontSize: 15,
          height: 1.5,
        ),
        bodyMedium: TextStyle(
          color: Color(0xFFA4B2AA),
          fontSize: 13,
          height: 1.45,
        ),
        labelLarge: TextStyle(
          color: Color(0xFFF1F5F1),
          fontSize: 13,
          fontWeight: FontWeight.w800,
        ),
      ),
      pageTransitionsTheme: _pageTransitionsTheme,
      splashFactory: InkSparkle.splashFactory,
      visualDensity: VisualDensity.standard,
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF102B26),
        foregroundColor: Color(0xFFF1F5F1),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: Color(0xFFF1F5F1),
          fontSize: 19,
          fontWeight: FontWeight.w800,
        ),
      ),
      cardTheme: CardThemeData(
        color: const Color(0xFF13221D),
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(DarbRadius.lg),
          side: const BorderSide(color: Color(0xFF2A3B33)),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: const Color(0xFF13221D),
        indicatorColor: const Color(0xFF29483B),
        iconTheme: WidgetStateProperty.resolveWith(
          (states) => IconThemeData(
            color: states.contains(WidgetState.selected)
                ? const Color(0xFFB9E4D2)
                : const Color(0xFFA4B2AA),
          ),
        ),
        labelTextStyle: WidgetStateProperty.resolveWith(
          (states) => TextStyle(
            color: states.contains(WidgetState.selected)
                ? const Color(0xFFF1F5F1)
                : const Color(0xFFA4B2AA),
            fontSize: 11,
            fontWeight: states.contains(WidgetState.selected)
                ? FontWeight.w800
                : FontWeight.w500,
          ),
        ),
        elevation: 0,
        height: 70,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF1A2D26),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 17),
        hintStyle: const TextStyle(color: Color(0xFFA4B2AA), fontSize: 14),
        labelStyle: const TextStyle(color: Color(0xFFA4B2AA)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFF2A3B33)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFF2A3B33)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFB9E4D2), width: 1.5),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: const Color(0xFFB9E4D2),
          foregroundColor: const Color(0xFF102B26),
          minimumSize: const Size(0, 52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(DarbRadius.md),
          ),
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: const Color(0xFFB9E4D2),
          minimumSize: const Size(0, 50),
          side: const BorderSide(color: Color(0xFF2A3B33)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(DarbRadius.md),
          ),
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: const Color(0xFFB9E4D2),
          textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: const Color(0xFF1A2D26),
        selectedColor: const Color(0xFF29483B),
        side: const BorderSide(color: Color(0xFF2A3B33)),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(DarbRadius.pill),
        ),
        labelStyle: const TextStyle(
          color: Color(0xFFF1F5F1),
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: Color(0xFFC8F169),
        foregroundColor: Color(0xFF102B26),
        elevation: 2,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: const Color(0xFF13221D),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(DarbRadius.xl),
        ),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: Color(0xFF13221D),
        surfaceTintColor: Colors.transparent,
        showDragHandle: true,
        dragHandleColor: Color(0xFF40564A),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(DarbRadius.xl),
          ),
        ),
      ),
      dividerTheme:
          const DividerThemeData(color: Color(0xFF2A3B33), thickness: 1),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: Color(0xFFB9E4D2),
        linearTrackColor: Color(0xFF2A3B33),
        circularTrackColor: Color(0xFF2A3B33),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF1C342C),
        contentTextStyle: const TextStyle(
          color: Color(0xFFF1F5F1),
          fontWeight: FontWeight.w600,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
    );
  }

  static ThemeData get light {
    const scheme = ColorScheme(
      brightness: Brightness.light,
      primary: Color(0xFF102B26),
      onPrimary: Colors.white,
      secondary: Color(0xFFC8F169),
      onSecondary: Color(0xFF102B26),
      error: Color(0xFFB94747),
      onError: Colors.white,
      surface: Color(0xFFFFFFFF),
      onSurface: Color(0xFF17231F),
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: const Color(0xFFF5F6F2),
      fontFamily: 'Arial',
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          color: Color(0xFF17231F),
          fontSize: 28,
          fontWeight: FontWeight.w900,
          height: 1.2,
        ),
        headlineMedium: TextStyle(
          color: Color(0xFF17231F),
          fontSize: 23,
          fontWeight: FontWeight.w900,
          height: 1.25,
        ),
        titleLarge: TextStyle(
          color: Color(0xFF17231F),
          fontSize: 19,
          fontWeight: FontWeight.w800,
        ),
        titleMedium: TextStyle(
          color: Color(0xFF17231F),
          fontSize: 15,
          fontWeight: FontWeight.w700,
        ),
        bodyLarge: TextStyle(
          color: Color(0xFF17231F),
          fontSize: 15,
          height: 1.5,
        ),
        bodyMedium: TextStyle(
          color: Color(0xFF77837D),
          fontSize: 13,
          height: 1.45,
        ),
        labelLarge: TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
      ),
      pageTransitionsTheme: _pageTransitionsTheme,
      splashFactory: InkSparkle.splashFactory,
      visualDensity: VisualDensity.standard,
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: Color(0xFF102B26),
        linearTrackColor: Color(0xFFE4E9E3),
        circularTrackColor: Color(0xFFE4E9E3),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: const Color(0xFFFFFFFF),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(DarbRadius.xl),
        ),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: Color(0xFFFFFFFF),
        surfaceTintColor: Colors.transparent,
        showDragHandle: true,
        dragHandleColor: Color(0xFFCBD5CE),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(DarbRadius.xl),
          ),
        ),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFFF5F6F2),
        foregroundColor: Color(0xFF17231F),
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: Color(0xFF17231F),
          fontSize: 19,
          fontWeight: FontWeight.w800,
        ),
      ),
      cardTheme: CardThemeData(
        color: const Color(0xFFFFFFFF),
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
          side: const BorderSide(color: Color(0xFFE4E9E3)),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: const Color(0xFFFFFFFF),
        indicatorColor: const Color(0xFFB9E4D2).withValues(alpha: .55),
        iconTheme: WidgetStateProperty.resolveWith(
          (states) => IconThemeData(
            color: states.contains(WidgetState.selected)
                ? const Color(0xFF102B26)
                : const Color(0xFF77837D),
          ),
        ),
        labelTextStyle: WidgetStateProperty.resolveWith(
          (states) => TextStyle(
            fontSize: 11,
            fontWeight: states.contains(WidgetState.selected)
                ? FontWeight.w800
                : FontWeight.w500,
          ),
        ),
        elevation: 0,
        height: 70,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFFFFFFFF),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 17),
        hintStyle: const TextStyle(color: Color(0xFF77837D), fontSize: 14),
        labelStyle: const TextStyle(color: Color(0xFF77837D)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFE4E9E3)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFE4E9E3)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFF102B26), width: 1.5),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: const Color(0xFF102B26),
          foregroundColor: Colors.white,
          minimumSize: const Size(0, 52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: const Color(0xFF102B26),
          minimumSize: const Size(0, 50),
          side: const BorderSide(color: Color(0xFFE4E9E3)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: const Color(0xFF102B26),
          textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: const Color(0xFFEAF2EC),
        selectedColor: const Color(0xFFB9E4D2),
        side: const BorderSide(color: Color(0xFFE4E9E3)),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(DarbRadius.pill),
        ),
        labelStyle: const TextStyle(
          color: Color(0xFF17231F),
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: Color(0xFF102B26),
        foregroundColor: Colors.white,
        elevation: 2,
      ),
      dividerTheme:
          const DividerThemeData(color: Color(0xFFE4E9E3), thickness: 1),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF102B26),
        contentTextStyle: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w600,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
    );
  }
}
