import 'dart:async';

import 'package:flutter/material.dart';

import '../design_system.dart';

class DarbCityCarousel extends StatefulWidget {
  const DarbCityCarousel({super.key});

  @override
  State<DarbCityCarousel> createState() => _DarbCityCarouselState();
}

class _DarbCityCarouselState extends State<DarbCityCarousel> {
  static const _cities = <_CitySlide>[
    _CitySlide('aleppo', 'حلب', 'Aleppo', 'Halep'),
    _CitySlide('homs', 'حمص', 'Homs', 'Humus'),
    _CitySlide('hama', 'حماة', 'Hama', 'Hama'),
    _CitySlide('damascus', 'دمشق', 'Damascus', 'Şam'),
    _CitySlide('latakia', 'اللاذقية', 'Latakia', 'Lazkiye'),
  ];

  late final PageController _pageController;
  Timer? _timer;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _syncAutoAdvance();
  }

  void _syncAutoAdvance() {
    if (DarbMotion.reduceMotion(context)) {
      _timer?.cancel();
      _timer = null;
      return;
    }
    _timer ??= Timer.periodic(const Duration(seconds: 7), (_) {
      if (!mounted || DarbMotion.reduceMotion(context)) return;
      final next = (_index + 1) % _cities.length;
      _goToCity(next);
    });
  }

  void _goToCity(int target) {
    if (!mounted) return;
    setState(() => _index = target);
    if (_pageController.hasClients) {
      if (DarbMotion.reduceMotion(context)) {
        _pageController.jumpToPage(target);
      } else {
        _pageController.animateToPage(
          target,
          duration: DarbMotion.expressive,
          curve: DarbMotion.enter,
        );
      }
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final city = _cities[_index];
    final language = Localizations.localeOf(context).languageCode;
    final cityName = switch (language) {
      'en' => city.english,
      'tr' => city.turkish,
      _ => city.arabic,
    };
    final duration = DarbMotion.effectiveDuration(
      context,
      const Duration(milliseconds: 900),
    );
    final reduced = DarbMotion.reduceMotion(context);

    return Stack(
      fit: StackFit.expand,
      children: [
        PageView.builder(
          controller: _pageController,
          itemCount: _cities.length,
          onPageChanged: (page) {
            if (mounted && _index != page) {
              setState(() => _index = page);
            }
          },
          itemBuilder: (context, idx) {
            final item = _cities[idx];
            final active = idx == _index;
            return AnimatedScale(
              scale: reduced ? 1 : (active ? 1.0 : 1.04),
              duration: duration,
              curve: DarbMotion.enter,
              child: Image.asset(
                'assets/cities/${item.assetName}.jpg',
                key: ValueKey('city_slide_${item.assetName}'),
                fit: BoxFit.cover,
                alignment: Alignment.center,
                errorBuilder: (_, __, ___) => DecoratedBox(
                  decoration: BoxDecoration(gradient: DarbColors.heroGradient),
                ),
              ),
            );
          },
        ),
        const IgnorePointer(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0x2E000000), Color(0xD4102B26)],
              ),
            ),
          ),
        ),
        PositionedDirectional(
          top: 78,
          end: 18,
          child: AnimatedSwitcher(
            duration: DarbMotion.effectiveDuration(context, DarbMotion.route),
            switchInCurve: DarbMotion.enter,
            switchOutCurve: DarbMotion.exit,
            child: Container(
              key: ValueKey('city_badge_${city.assetName}'),
              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
              decoration: BoxDecoration(
                color: const Color(0xB3102B26),
                borderRadius: BorderRadius.circular(DarbRadius.pill),
                border: Border.all(color: Colors.white.withValues(alpha: .25)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.location_on_rounded,
                    color: Color(0xFFC8F169),
                    size: 14,
                  ),
                  const SizedBox(width: 5),
                  Text(
                    cityName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        PositionedDirectional(
          bottom: 14,
          end: 20,
          child: Row(
            children: List.generate(
              _cities.length,
              (index) => GestureDetector(
                key: ValueKey('city_dot_${_cities[index].assetName}'),
                behavior: HitTestBehavior.opaque,
                onTap: () => _goToCity(index),
                child: Padding(
                  padding: const EdgeInsetsDirectional.only(
                    start: 4,
                    top: 6,
                    bottom: 6,
                  ),
                  child: AnimatedContainer(
                    duration: DarbMotion.effectiveDuration(
                      context,
                      DarbMotion.fast,
                    ),
                    curve: DarbMotion.enter,
                    width: index == _index ? 18 : 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(
                        alpha: index == _index ? .95 : .48,
                      ),
                      borderRadius: BorderRadius.circular(DarbRadius.pill),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _CitySlide {
  const _CitySlide(this.assetName, this.arabic, this.english, this.turkish);
  final String assetName;
  final String arabic;
  final String english;
  final String turkish;
}
