part of 'app_shell.dart';

class CustomerHome extends StatefulWidget {
  final VoidCallback? onOpenOrders;
  const CustomerHome({super.key, this.onOpenOrders});
  @override
  State<CustomerHome> createState() => _CustomerHomeState();
}

class _CustomerHomeState extends State<CustomerHome> {
  final search = TextEditingController();
  final storesKey = GlobalKey();
  bool loading = true;
  String? error;
  List<dynamic> cities = [], vendors = [];
  Map<String, dynamic>? _activeOrder;
  String? cityId;
  String selectedCategory = '';
  int _loadGeneration = 0;

  @override
  void initState() {
    super.initState();
    darbLocale.addListener(_onLocaleChanged);
    search.addListener(() {
      if (mounted) setState(() {});
    });
    _load();
  }

  void _onLocaleChanged() => _load();

  @override
  void dispose() {
    darbLocale.removeListener(_onLocaleChanged);
    search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final generation = ++_loadGeneration;
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }
    try {
      final loadedCities = await Api.instance.get('/cities') as List;
      if (generation != _loadGeneration) return;
      cities = loadedCities;
      if (cities.isNotEmpty) {
        if (cityId == null || !cities.any((c) => c['id'].toString() == cityId)) {
          cityId = cities.first['id'].toString();
        }
        final locale = darbLocale.value.languageCode;
        final loadedVendors = await Api.instance.get(
          '/vendors?cityId=$cityId&locale=$locale',
        ) as List;
        if (generation != _loadGeneration) return;
        vendors = loadedVendors;
        if (selectedCategory.isNotEmpty &&
            !vendors.any((v) =>
                (v['type']?.toString().trim() ?? '') == selectedCategory)) {
          selectedCategory = '';
        }
      } else {
        cityId = null;
        vendors = [];
        selectedCategory = '';
      }
      await _loadActiveOrder(generation);
    } catch (e) {
      if (generation == _loadGeneration) error = e.toString();
    } finally {
      if (mounted && generation == _loadGeneration) {
        setState(() => loading = false);
      }
    }
  }

  Future<void> _loadActiveOrder(int generation) async {
    try {
      final mine = await Api.instance.get('/orders/mine');
      if (generation != _loadGeneration || mine is! List) return;
      Map<String, dynamic>? found;
      for (final item in mine) {
        if (item is Map) {
          final status = item['status']?.toString() ?? '';
          if (status != 'DELIVERED' && status != 'CANCELLED') {
            found = Map<String, dynamic>.from(item);
            break;
          }
        }
      }
      _activeOrder = found;
    } catch (_) {
      // Active order banner is non-blocking for home discovery.
    }
  }

  String _cityName(dynamic city) {
    final names = city['names'] as List? ?? [];
    final locale = darbLocale.value.languageCode;
    for (final item in names) {
      if (item is Map && item['locale'] == locale) return item['name'].toString();
    }
    for (final item in names) {
      if (item is Map && item['locale'] == 'ar') return item['name'].toString();
    }
    return names.isEmpty
        ? city['code'].toString()
        : names.first['name'].toString();
  }

  String _vendorName(dynamic vendor) {
    final translations = vendor['translations'] as List? ?? [];
    final locale = darbLocale.value.languageCode;
    for (final item in translations) {
      if (item is Map && item['locale'] == locale) return item['name'].toString();
    }
    for (final item in translations) {
      if (item is Map && item['locale'] == 'ar') return item['name'].toString();
    }
    return translations.isEmpty
        ? dt('متجر')
        : translations.first['name']?.toString() ?? dt('متجر');
  }

  void _openPeerDelivery() {
    if (cityId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(dt('لا توجد مدينة مفعّلة لخدمة التوصيل حالياً'))),
      );
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PeerDeliveryScreen(cityId: cityId!)),
    ).then((_) {
      if (mounted) _load();
    });
  }

  Future<void> _openAiOrderAssistant() async {
    if (cityId == null) return;
    final action = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (_) => AiOrderAssistantScreen(cityId: cityId!),
      ),
    );
    if (!mounted) return;
    if (action == 'peer') {
      _openPeerDelivery();
    } else if (action == 'stores') {
      _openStores();
    }
  }

  void _openSavedAddresses() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const SavedAddressesScreen()),
    );
  }

  void _openStores() {
    final target = storesKey.currentContext;
    if (target == null) return;
    Scrollable.ensureVisible(
      target,
      duration: DarbMotion.effectiveDuration(
        context,
        const Duration(milliseconds: 520),
      ),
      curve: DarbMotion.enter,
      alignment: .04,
    );
  }

  Widget _serviceCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool primary = false,
  }) {
    final foreground = primary ? Colors.white : DarbColors.ink;
    return DarbSurfaceCard(
      onTap: onTap,
      enableHaptics: true,
      backgroundColor: primary ? DarbColors.forestSoft : DarbColors.surface,
      borderColor: primary ? Colors.transparent : DarbColors.line,
      borderRadius: 21,
      padding: const EdgeInsets.all(15),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: primary
                  ? Colors.white.withValues(alpha: .12)
                  : DarbColors.surfaceAlt,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Icon(
              icon,
              color: primary ? DarbColors.lime : DarbColors.brandForeground,
              size: 23,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  textAlign: TextAlign.start,
                  style: TextStyle(
                    color: foreground,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  textAlign: TextAlign.start,
                  style: TextStyle(
                    color: primary
                        ? Colors.white.withValues(alpha: .76)
                        : DarbColors.muted,
                    fontSize: 11.5,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            DarbIcons.chevronForward(context),
            size: 20,
            color: primary ? Colors.white70 : DarbColors.muted,
          ),
        ],
      ),
    );
  }

  Widget _storeTile(dynamic vendor) {
    final name = _vendorName(vendor);
    final count = vendor['_count']?['products'] ?? 0;
    final type = vendor['type']?.toString().trim() ?? '';
    final address = (vendor['location'] is Map)
        ? vendor['location']['address']?.toString().trim() ?? ''
        : '';
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: DarbSurfaceCard(
        borderRadius: 19,
        padding: const EdgeInsets.all(13),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => VendorCatalog(
              vendorId: vendor['id'].toString(),
              name: name,
              cityId: cityId ?? '',
            ),
          ),
        ).then((_) {
          if (mounted) _load();
        }),
        child: Row(
          children: [
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                color: DarbColors.surfaceAlt,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(
                Icons.storefront_rounded,
                color: DarbColors.brandForeground,
                size: 25,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: DarbColors.ink,
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      if (type.isNotEmpty) ...[
                        const SizedBox(width: 6),
                        DarbStatusBadge(label: type, tone: DarbTone.brand),
                      ],
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(
                    [
                      dt('$count منتج متاح'),
                      if (address.isNotEmpty) address,
                    ].join(' • '),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: DarbColors.muted, fontSize: 11.5),
                  ),
                ],
              ),
            ),
            Icon(
              DarbIcons.chevronForward(context),
              color: DarbColors.brandForeground,
              size: 23,
            ),
          ],
        ),
      ),
    );
  }

  Widget _activeOrderCard() {
    final order = _activeOrder;
    if (order == null) return const SizedBox.shrink();
    final orderNumber = order['orderNumber']?.toString() ?? order['id']?.toString() ?? '';
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: DarbSurfaceCard(
        onTap: widget.onOpenOrders,
        backgroundColor: DarbColors.surfaceElevated,
        borderColor: DarbColors.brandForeground.withValues(alpha: .35),
        padding: const EdgeInsets.all(15),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: DarbColors.info.withValues(alpha: .14),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(Icons.local_shipping_rounded, color: DarbColors.info),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DarbStatusBadge(
                    label: dt('توصيل نشط الآن'),
                    tone: DarbTone.info,
                    pulse: true,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '${dt('رقم الطلب')}: $orderNumber',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: DarbColors.ink,
                      fontWeight: FontWeight.w800,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
            TextButton(
              onPressed: widget.onOpenOrders,
              child: Text(dt('متابعة الطلب')),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final query = search.text.trim().toLowerCase();
    final categories = <String>{
      for (final v in vendors)
        if ((v['type']?.toString().trim() ?? '').isNotEmpty)
          v['type'].toString().trim(),
    }.toList();
    final visibleVendors = vendors.where((v) {
      final type = v['type']?.toString().trim() ?? '';
      if (selectedCategory.isNotEmpty && type != selectedCategory) {
        return false;
      }
      if (query.isEmpty) return true;
      return _vendorName(v).toLowerCase().contains(query) ||
          type.toLowerCase().contains(query);
    }).toList();

    return RefreshIndicator(
      onRefresh: _load,
      color: DarbColors.brandForeground,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(18, 10, 18, 30),
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: DarbColors.surfaceAlt,
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(
                  Icons.location_on_rounded,
                  color: DarbColors.brandForeground,
                  size: 20,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      dt('موقع التوصيل'),
                      style: TextStyle(color: DarbColors.muted, fontSize: 10.5),
                    ),
                    const SizedBox(height: 2),
                    if (cities.isNotEmpty)
                      DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          isDense: true,
                          value: cityId,
                          dropdownColor: DarbColors.surfaceElevated,
                          icon: Icon(
                            Icons.keyboard_arrow_down_rounded,
                            color: DarbColors.brandForeground,
                          ),
                          style: TextStyle(
                            color: DarbColors.ink,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w900,
                          ),
                          items: [
                            for (final c in cities)
                              DropdownMenuItem(
                                value: c['id'].toString(),
                                child: Text(_cityName(c)),
                              ),
                          ],
                          onChanged: (value) async {
                            if (value == null || value == cityId) return;
                            setState(() => cityId = value);
                            await _load();
                          },
                        ),
                      )
                    else
                      Text(
                        dt('المدينة غير متاحة'),
                        style: TextStyle(
                          color: DarbColors.ink,
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                  ],
                ),
              ),
              IconButton(
                tooltip: dt('العناوين المحفوظة'),
                onPressed: _openSavedAddresses,
                icon: Icon(Icons.bookmarks_outlined, color: DarbColors.brandForeground),
              ),
              IconButton(
                tooltip: dt('تحديث'),
                onPressed: _load,
                icon: Icon(Icons.refresh_rounded, color: DarbColors.muted),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _activeOrderCard(),
          Container(
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              gradient: DarbColors.heroGradient,
              borderRadius: BorderRadius.circular(27),
              boxShadow: DarbElevation.cardFor(Theme.of(context).brightness),
            ),
            child: Stack(
              children: [
                PositionedDirectional(
                  end: -48,
                  top: -64,
                  child: Container(
                    width: 190,
                    height: 190,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white.withValues(alpha: .07),
                        width: 27,
                      ),
                    ),
                  ),
                ),
                PositionedDirectional(
                  end: 28,
                  bottom: -95,
                  child: Container(
                    width: 175,
                    height: 175,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withValues(alpha: .035),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(21, 22, 21, 21),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: .10),
                          borderRadius: BorderRadius.circular(DarbRadius.pill),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.route_rounded,
                              color: DarbColors.lime,
                              size: 14,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              dt('خدمة التوصيل المستقل'),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10.5,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        dt('من بابك إلى وجهتك،\nدَرْب يتولى الطريق.'),
                        textAlign: TextAlign.start,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          height: 1.22,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -.3,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        dt('أرسل غرضك بسهولة، واستقبل عروض السائقين واختر الأجرة المناسبة لك.'),
                        textAlign: TextAlign.start,
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: .80),
                          fontSize: 12,
                          height: 1.55,
                        ),
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton(
                          onPressed: cityId == null ? null : _openPeerDelivery,
                          style: FilledButton.styleFrom(
                            backgroundColor: DarbColors.lime,
                            foregroundColor: DarbColors.forest,
                            minimumSize: const Size(0, 52),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(DarbRadius.md),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.near_me_rounded, size: 18),
                              const SizedBox(width: 8),
                              Text(
                                dt('ابدأ طلب توصيل'),
                                style: const TextStyle(fontWeight: FontWeight.w900),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 11),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.verified_user_outlined,
                            color: DarbColors.mint,
                            size: 13,
                          ),
                          const SizedBox(width: 5),
                          Flexible(
                            child: Text(
                              dt('قارن عروض السائقين قبل اختيار الأجرة'),
                              style: TextStyle(
                                color: DarbColors.mint,
                                fontSize: 10.5,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          DarbSectionHeader(
            title: dt('كيف تريد استخدام دَرْب؟'),
            subtitle: dt('اختر المسار الذي يناسب احتياجك'),
          ),
          const SizedBox(height: 12),
          DarbFadeSlide(
            delay: DarbMotion.cappedStaggerDelay(0),
            child: _serviceCard(
              icon: Icons.inventory_2_outlined,
              title: dt('إرسال غرض مستقل'),
              subtitle: dt('أرسل طرداً أو غرضاً من أي عنوان إلى آخر'),
              onTap: _openPeerDelivery,
              primary: true,
            ),
          ),
          const SizedBox(height: 9),
          DarbFadeSlide(
            delay: DarbMotion.cappedStaggerDelay(1),
            child: _serviceCard(
              icon: Icons.auto_awesome_rounded,
              title: dt('اطلب بمساعدة الذكاء الاصطناعي'),
              subtitle: dt('اكتب طلبك باللهجة التي تستخدمها ودع دَرْب يحوله إلى مسودة للمراجعة'),
              onTap: _openAiOrderAssistant,
            ),
          ),
          const SizedBox(height: 9),
          DarbFadeSlide(
            delay: DarbMotion.cappedStaggerDelay(2),
            child: _serviceCard(
              icon: Icons.storefront_outlined,
              title: dt('الطلب من المتاجر'),
              subtitle: dt('تصفح المتاجر والمنتجات واطلب إلى بابك'),
              onTap: _openStores,
            ),
          ),
          const SizedBox(height: 25),
          Container(key: storesKey),
          DarbSectionHeader(
            title: dt('متاجر مدينتك'),
            subtitle: dt('تصفح المتاجر المتاحة وابدأ طلبك'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: search,
            textInputAction: TextInputAction.search,
            decoration: InputDecoration(
              hintText: dt('ابحث عن متجر أو نشاط...'),
              prefixIcon: Icon(
                Icons.search_rounded,
                color: DarbColors.brandForeground,
              ),
              suffixIcon: search.text.isEmpty
                  ? null
                  : IconButton(
                      onPressed: search.clear,
                      icon: const Icon(Icons.close_rounded),
                    ),
            ),
          ),
          if (categories.isNotEmpty) ...[
            const SizedBox(height: 11),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  ChoiceChip(
                    label: Text(dt('الكل')),
                    selected: selectedCategory.isEmpty,
                    onSelected: (_) => setState(() => selectedCategory = ''),
                  ),
                  for (final category in categories) ...[
                    const SizedBox(width: 8),
                    ChoiceChip(
                      label: Text(category),
                      selected: selectedCategory == category,
                      onSelected: (_) =>
                          setState(() => selectedCategory = category),
                    ),
                  ],
                ],
              ),
            ),
          ],
          const SizedBox(height: 13),
          if (loading)
            ...List.generate(
              3,
              (_) => const Padding(
                padding: EdgeInsets.only(bottom: 10),
                child: DarbSkeletonCard(lines: 2),
              ),
            )
          else if (error != null)
            _ErrorPanel(message: error!, retry: _load)
          else if (visibleVendors.isEmpty)
            DarbSurfaceCard(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 22),
              borderRadius: 21,
              child: Column(
                children: [
                  Container(
                    width: 55,
                    height: 55,
                    decoration: BoxDecoration(
                      color: DarbColors.surfaceAlt,
                      borderRadius: BorderRadius.circular(17),
                    ),
                    child: Icon(
                      Icons.storefront_outlined,
                      color: DarbColors.brandForeground,
                      size: 27,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    query.isEmpty
                        ? dt('لا توجد متاجر متاحة في هذه المدينة')
                        : dt('لم نعثر على نتائج مطابقة'),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: DarbColors.ink,
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    dt('يمكنك استخدام خدمة التوصيل المستقل حتى عندما لا تتوفر متاجر في مدينتك.'),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: DarbColors.muted,
                      fontSize: 11.5,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 13),
                  OutlinedButton.icon(
                    onPressed: _openPeerDelivery,
                    icon: const Icon(Icons.near_me_rounded, size: 17),
                    label: Text(dt('إنشاء طلب توصيل مستقل')),
                  ),
                ],
              ),
            )
          else
            ...List.generate(
              visibleVendors.length,
              (index) => DarbFadeSlide(
                delay: DarbMotion.cappedStaggerDelay(index),
                child: _storeTile(visibleVendors[index]),
              ),
            ),
        ],
      ),
    );
  }
}

class SavedAddressesScreen extends StatefulWidget {
  const SavedAddressesScreen({super.key});

  @override
  State<SavedAddressesScreen> createState() => _SavedAddressesScreenState();
}

class _SavedAddressesScreenState extends State<SavedAddressesScreen> {
  bool loading = true;
  bool saving = false;
  String? error;
  List<Map<String, dynamic>> addresses = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }
    try {
      final result = await Api.instance.get('/addresses');
      if (result is! List) throw Exception(dt('تعذر قراءة عناوين التوصيل'));
      addresses = result.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (e) {
      error = e.toString();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _addressDialog({Map<String, dynamic>? existing}) async {
    final formKey = GlobalKey<FormState>();
    final label = TextEditingController(
      text: existing?['label']?.toString() ?? '',
    );
    final details = TextEditingController(
      text: existing?['details']?.toString() ?? '',
    );
    double? latitude;
    double? longitude;
    bool locating = false;
    String? locationError;
    final hasExistingGps = existing?['hasLocation'] == true;

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: Text(
            existing == null ? dt('إضافة عنوان جديد') : dt('تعديل العنوان'),
          ),
          content: SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: label,
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                      labelText: dt('اسم العنوان (اختياري)'),
                      prefixIcon: const Icon(Icons.bookmark_outline_rounded),
                    ),
                    validator: (v) => (v?.trim().length ?? 0) > 40
                        ? dt('اسم العنوان طويل جداً')
                        : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: details,
                    minLines: 2,
                    maxLines: 3,
                    maxLength: 500,
                    decoration: InputDecoration(
                      labelText: dt('العنوان بالتفصيل'),
                      hintText: dt('الحي، الشارع، البناء، الطابق...'),
                      prefixIcon: const Icon(Icons.location_on_outlined),
                      alignLabelWithHint: true,
                    ),
                    validator: (v) {
                      final text = v?.trim() ?? '';
                      if (text.isEmpty) return dt('أدخل تفاصيل العنوان');
                      if (text.length > 500) return dt('تفاصيل العنوان طويلة جداً');
                      return null;
                    },
                  ),
                  const SizedBox(height: 6),
                  OutlinedButton.icon(
                    onPressed: locating
                        ? null
                        : () async {
                            setDialogState(() {
                              locating = true;
                              locationError = null;
                            });
                            try {
                              if (!await Geolocator.isLocationServiceEnabled()) {
                                throw Exception(dt('فعّل خدمة الموقع في هاتفك أولاً'));
                              }
                              var permission = await Geolocator.checkPermission();
                              if (permission == LocationPermission.denied) {
                                permission = await Geolocator.requestPermission();
                              }
                              if (permission == LocationPermission.denied ||
                                  permission == LocationPermission.deniedForever) {
                                throw Exception(dt('يلزم السماح للتطبيق بالوصول إلى موقعك'));
                              }
                              final point = await Geolocator.getCurrentPosition(
                                locationSettings: const LocationSettings(
                                  accuracy: LocationAccuracy.high,
                                  timeLimit: Duration(seconds: 20),
                                ),
                              );
                              latitude = point.latitude;
                              longitude = point.longitude;
                            } catch (e) {
                              locationError = e.toString();
                            } finally {
                              if (dialogContext.mounted) {
                                setDialogState(() => locating = false);
                              }
                            }
                          },
                    icon: locating
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Icon(
                            latitude != null || hasExistingGps
                                ? Icons.check_circle_rounded
                                : Icons.my_location_rounded,
                          ),
                    label: Text(
                      locating
                          ? dt('جارٍ تحديد الموقع...')
                          : latitude != null
                              ? dt('تم تحديد الموقع')
                              : hasExistingGps
                                  ? dt('تحديث الإحداثيات الحالية')
                                  : dt('استخدام موقعي الحالي'),
                    ),
                  ),
                  if (locationError != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        locationError!,
                        style: TextStyle(color: DarbColors.danger, fontSize: 12),
                      ),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: locating ? null : () => Navigator.pop(dialogContext, false),
              child: Text(dt('إلغاء')),
            ),
            FilledButton(
              onPressed: locating
                  ? null
                  : () {
                      if (formKey.currentState?.validate() ?? false) {
                        Navigator.pop(dialogContext, true);
                      }
                    },
              child: Text(dt('حفظ العنوان')),
            ),
          ],
        ),
      ),
    );

    if (saved == true && mounted) {
      setState(() => saving = true);
      try {
        final payload = <String, dynamic>{
          'label': label.text.trim(),
          'details': details.text.trim(),
          if (latitude != null && longitude != null) 'latitude': latitude,
          if (latitude != null && longitude != null) 'longitude': longitude,
        };
        if (existing == null) {
          await Api.instance.post('/addresses', payload);
        } else {
          await Api.instance.patch('/addresses/${existing['id']}', payload);
        }
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(dt('تم حفظ العنوان بنجاح'))),
        );
        await _load();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(e.toString())),
          );
        }
      } finally {
        if (mounted) setState(() => saving = false);
      }
    }
    label.dispose();
    details.dispose();
  }

  Future<void> _deleteAddress(Map<String, dynamic> address) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        icon: Icon(Icons.delete_outline_rounded, color: DarbColors.danger),
        title: Text(dt('حذف العنوان')),
        content: Text(dt('هل أنت متأكد من حذف هذا العنوان؟')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(dt('إلغاء')),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: DarbColors.danger,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(dt('حذف')),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => saving = true);
    try {
      await Api.instance.delete('/addresses/${address['id']}', {});
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(dt('تم حذف العنوان'))),
      );
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString())),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(dt('العناوين المحفوظة'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: saving ? null : () => _addressDialog(),
        icon: const Icon(Icons.add_location_alt_outlined),
        label: Text(dt('إضافة عنوان')),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 92),
          children: [
            DarbSurfaceCard(
              backgroundColor: DarbColors.surfaceAlt,
              padding: const EdgeInsets.all(14),
              child: Text(
                dt('أضف عناوينك وحدد مواقعها لحساب رسوم التوصيل بدقة'),
                style: TextStyle(color: DarbColors.muted, fontSize: 12, height: 1.5),
              ),
            ),
            const SizedBox(height: 14),
            if (loading)
              ...List.generate(
                3,
                (_) => const Padding(
                  padding: EdgeInsets.only(bottom: 10),
                  child: DarbSkeletonCard(lines: 2),
                ),
              )
            else if (error != null)
              _ErrorPanel(message: error!, retry: _load)
            else if (addresses.isEmpty)
              _EmptyPanel(text: dt('لا يوجد عنوان محفوظ. أضف عنواناً للمتابعة.'))
            else
              for (var i = 0; i < addresses.length; i++)
                DarbFadeSlide(
                  delay: DarbMotion.cappedStaggerDelay(i),
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: DarbSurfaceCard(
                      padding: const EdgeInsets.all(14),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: DarbColors.surfaceAlt,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Icon(
                              Icons.location_on_outlined,
                              color: DarbColors.brandForeground,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  (addresses[i]['label']?.toString().trim().isNotEmpty ?? false)
                                      ? addresses[i]['label'].toString()
                                      : dt('عنوان'),
                                  style: TextStyle(
                                    color: DarbColors.ink,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 14,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  addresses[i]['details']?.toString() ?? '',
                                  style: TextStyle(
                                    color: DarbColors.muted,
                                    fontSize: 12,
                                    height: 1.4,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                DarbStatusBadge(
                                  label: addresses[i]['hasLocation'] == true
                                      ? dt('موقع محدد')
                                      : dt('الموقع غير محدد'),
                                  tone: addresses[i]['hasLocation'] == true
                                      ? DarbTone.success
                                      : DarbTone.warning,
                                ),
                              ],
                            ),
                          ),
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                tooltip: dt('تعديل'),
                                onPressed: saving
                                    ? null
                                    : () => _addressDialog(existing: addresses[i]),
                                icon: const Icon(Icons.edit_outlined, size: 19),
                                constraints: const BoxConstraints.tightFor(
                                  width: 34,
                                  height: 34,
                                ),
                                padding: EdgeInsets.zero,
                              ),
                              IconButton(
                                tooltip: dt('حذف'),
                                onPressed: saving
                                    ? null
                                    : () => _deleteAddress(addresses[i]),
                                icon: Icon(
                                  Icons.delete_outline_rounded,
                                  size: 19,
                                  color: DarbColors.danger,
                                ),
                                constraints: const BoxConstraints.tightFor(
                                  width: 34,
                                  height: 34,
                                ),
                                padding: EdgeInsets.zero,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
          ],
        ),
      ),
    );
  }
}

class AiOrderAssistantScreen extends StatefulWidget {
  final String cityId;
  const AiOrderAssistantScreen({super.key, required this.cityId});
  @override
  State<AiOrderAssistantScreen> createState() => _AiOrderAssistantScreenState();
}

class _AiOrderAssistantScreenState extends State<AiOrderAssistantScreen> {
  final _text = TextEditingController();
  bool _loading = false;
  String? _error;
  Map<String, dynamic>? _draft;

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _analyze() async {
    final value = _text.text.trim();
    if (value.length < 5 || value.length > 3000) {
      setState(() => _error = dt('اكتب طلباً بين 5 و3000 محرف'));
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      _loading = true;
      _error = null;
      _draft = null;
    });
    try {
      final result = await Api.instance.post('/ai/order-assistant/drafts/text', {
        'cityId': widget.cityId,
        'text': value,
      });
      if (result is! Map) throw const ApiException('استجابة المساعد غير صالحة');
      if (mounted) setState(() => _draft = Map<String, dynamic>.from(result));
    } catch (_) {
      if (mounted) {
        setState(
          () => _error = dt('تعذر تحليل الطلب حالياً. تحقق من اتصال الإنترنت ثم أعد المحاولة.'),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _intentLabel(String? intent) {
    switch (intent) {
      case 'STORE_ORDER':
        return dt('طلب من متجر');
      case 'PEER_DELIVERY':
        return dt('توصيل غرض مستقل');
      default:
        return dt('يحتاج إلى توضيح');
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = (_draft?['items'] as List?) ?? const [];
    final warnings = (_draft?['warnings'] as List?) ?? const [];
    final intent = _draft?['intent']?.toString();
    return Scaffold(
      appBar: AppBar(
        title: Text(dt('مساعد دَرْب الذكي')),
        backgroundColor: DarbColors.forest,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: DarbColors.heroGradient,
              borderRadius: BorderRadius.circular(DarbRadius.xl),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.auto_awesome_rounded, color: DarbColors.lime, size: 28),
                const SizedBox(height: 12),
                Text(
                  dt('احكِ طلبك بطريقتك'),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 21,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  dt('اكتب باللهجة السورية أو العربية. سيستخرج المساعد نوع الطلب والمنتجات والعنوان، ثم يعرضها عليك للمراجعة.'),
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: .80),
                    height: 1.55,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: _text,
            minLines: 5,
            maxLines: 8,
            maxLength: 3000,
            decoration: InputDecoration(
              labelText: dt('اكتب طلبك هنا'),
              hintText: dt('مثال: بدي كيلو موز وحليب، والتوصيل على عنواني...'),
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: _loading ? null : _analyze,
              icon: _loading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.auto_awesome_rounded),
              label: Text(
                _loading ? dt('جارٍ تحليل طلبك...') : dt('حلّل الطلب'),
              ),
            ),
          ),
          if (_error != null) ...[
            const SizedBox(height: 14),
            _ErrorPanel(message: _error!, retry: _analyze),
          ],
          if (_draft != null) ...[
            const SizedBox(height: 22),
            DarbSectionHeader(title: dt('مسودة طلبك')),
            const SizedBox(height: 10),
            DarbSurfaceCard(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          _intentLabel(intent),
                          style: TextStyle(
                            color: DarbColors.ink,
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                          ),
                        ),
                      ),
                      DarbStatusBadge(
                        label: '${_draft?['status'] ?? ''}',
                        tone: DarbTone.info,
                      ),
                    ],
                  ),
                  if ((_draft?['transcript'] ?? '').toString().isNotEmpty) ...[
                    const Divider(height: 22),
                    Text(
                      _draft!['transcript'].toString(),
                      style: TextStyle(color: DarbColors.ink, height: 1.5),
                    ),
                  ],
                  if (items.isNotEmpty) ...[
                    const Divider(height: 22),
                    Text(
                      dt('العناصر المستخرجة'),
                      style: TextStyle(
                        color: DarbColors.ink,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    for (final item in items)
                      if (item is Map)
                        ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(
                            Icons.inventory_2_outlined,
                            color: DarbColors.brandForeground,
                          ),
                          title: Text(item['rawName']?.toString() ?? dt('عنصر')),
                          subtitle: Text(
                            dt('الكمية: ${item['quantity'] ?? 1} ${item['unit'] ?? ''}'),
                          ),
                          trailing: item['productId'] == null
                              ? Icon(
                                  Icons.help_outline_rounded,
                                  color: DarbColors.warning,
                                )
                              : Icon(
                                  Icons.check_circle_rounded,
                                  color: DarbColors.success,
                                ),
                        ),
                  ],
                  if (warnings.isNotEmpty) ...[
                    const Divider(height: 22),
                    Text(
                      dt('يحتاج إلى مراجعتك'),
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: DarbColors.warning,
                      ),
                    ),
                    for (final warning in warnings)
                      Padding(
                        padding: const EdgeInsets.only(top: 7),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              Icons.info_outline_rounded,
                              size: 17,
                              color: DarbColors.warning,
                            ),
                            const SizedBox(width: 7),
                            Expanded(
                              child: Text(
                                warning.toString(),
                                style: const TextStyle(fontSize: 12),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                  const SizedBox(height: 12),
                  Text(
                    dt('هذه مسودة فقط. لم يتم إنشاء طلب أو حجز منتجات أو تثبيت عنوان.'),
                    style: TextStyle(
                      color: DarbColors.muted,
                      fontSize: 11.5,
                      height: 1.5,
                    ),
                  ),
                  if (intent == 'PEER_DELIVERY' || intent == 'STORE_ORDER') ...[
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () => Navigator.pop(
                          context,
                          intent == 'PEER_DELIVERY' ? 'peer' : 'stores',
                        ),
                        icon: Icon(
                          intent == 'PEER_DELIVERY'
                              ? Icons.near_me_rounded
                              : Icons.storefront_rounded,
                        ),
                        label: Text(
                          intent == 'PEER_DELIVERY'
                              ? dt('إنشاء طلب توصيل مستقل')
                              : dt('العودة لاختيار متجر'),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
