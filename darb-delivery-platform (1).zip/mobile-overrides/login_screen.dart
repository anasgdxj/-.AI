import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../core/api.dart';
import '../design_system.dart';
import '../localizations.dart';
import 'app_shell.dart';
import 'city_carousel.dart';

const _googleServerClientId = String.fromEnvironment('GOOGLE_SERVER_CLIENT_ID');

Map<String, dynamic>? extractValidAuthTokens(dynamic response) {
  if (response is! Map) return null;
  final rawTokens = response['tokens'];
  if (rawTokens is! Map) return null;
  final access = rawTokens['accessToken'];
  final refresh = rawTokens['refreshToken'];
  if (access is! String || access.trim().isEmpty) return null;
  if (refresh is! String || refresh.trim().isEmpty) return null;
  return Map<String, dynamic>.from(rawTokens);
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  final phone = TextEditingController();
  final code = TextEditingController();
  final name = TextEditingController();

  bool sent = false;
  bool busy = false;
  bool googleLoading = false;
  bool _canRetry = false;
  String? error;
  int _resendCooldown = 0;
  Timer? _resendTimer;
  VoidCallback? _retryAction;

  late final AnimationController _entrance = AnimationController(
    vsync: this,
    duration: DarbMotion.expressive,
  );
  late final AnimationController _shake = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 420),
  );
  late final Animation<double> _shakeX = TweenSequence<double>([
    TweenSequenceItem(tween: Tween(begin: 0, end: -9), weight: 1),
    TweenSequenceItem(tween: Tween(begin: -9, end: 9), weight: 2),
    TweenSequenceItem(tween: Tween(begin: 9, end: -6), weight: 2),
    TweenSequenceItem(tween: Tween(begin: -6, end: 6), weight: 2),
    TweenSequenceItem(tween: Tween(begin: 6, end: 0), weight: 1),
  ]).animate(CurvedAnimation(parent: _shake, curve: Curves.easeOut));

  bool _entranceStarted = false;

  String get digits => phone.text.replaceAll(RegExp(r'\D'), '');
  bool get validPhone => RegExp(r'^09[3-9][0-9]{7}$').hasMatch(digits);
  bool get validOtp => code.text.trim().length == 6;
  bool get authenticating => busy || googleLoading;
  String get _e164Phone => '+963${digits.substring(1)}';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (DarbMotion.reduceMotion(context)) {
      _entranceStarted = true;
      _entrance.value = 1;
    } else if (!_entranceStarted) {
      _entranceStarted = true;
      _entrance.forward();
    }
  }

  @override
  void dispose() {
    _resendTimer?.cancel();
    phone.dispose();
    code.dispose();
    name.dispose();
    _entrance.dispose();
    _shake.dispose();
    super.dispose();
  }

  void _startResendCooldown() {
    _resendTimer?.cancel();
    setState(() => _resendCooldown = 60);
    _resendTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (_resendCooldown <= 1) {
        timer.cancel();
        setState(() => _resendCooldown = 0);
      } else {
        setState(() => _resendCooldown -= 1);
      }
    });
  }

  void _fail(
    String message, {
    bool retryable = false,
    VoidCallback? retryAction,
  }) {
    if (!mounted) return;
    setState(() {
      error = message;
      _canRetry = retryable;
      _retryAction = retryAction;
    });
    if (!DarbMotion.reduceMotion(context)) {
      _shake.forward(from: 0);
    }
    HapticFeedback.mediumImpact();
  }

  void _clearError() {
    if (error != null || _canRetry) {
      setState(() {
        error = null;
        _canRetry = false;
        _retryAction = null;
      });
    }
  }

  Future<void> requestCode() async {
    final l = AppLocalizations.of(context);
    if (!validPhone) {
      _fail(l.t('invalidPhone'));
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      busy = true;
      error = null;
      _canRetry = false;
      _retryAction = null;
    });
    try {
      await Api.instance.post('/auth/otp/request', {'phone': _e164Phone});
      if (!mounted) return;
      setState(() => sent = true);
      _startResendCooldown();
    } on ApiException catch (e) {
      _fail(e.message, retryable: true, retryAction: requestCode);
    } catch (_) {
      _fail(l.t('networkError'), retryable: true, retryAction: requestCode);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> verify() async {
    final l = AppLocalizations.of(context);
    if (!validOtp) {
      _fail(l.t('invalidOtp'));
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      busy = true;
      error = null;
      _canRetry = false;
      _retryAction = null;
    });
    try {
      final result = await Api.instance.post('/auth/otp/verify', {
        'phone': _e164Phone,
        'code': code.text.trim(),
        'name': name.text.trim().isEmpty ? null : name.text.trim(),
        'locale': darbLocale.value.languageCode,
      });
      final tokens = extractValidAuthTokens(result);
      if (tokens == null) {
        _fail(l.t('invalidAuthResponse'), retryable: true, retryAction: verify);
        return;
      }
      await Api.instance.saveTokens(tokens);
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const AppShell()),
        );
      }
    } on ApiException catch (e) {
      _fail(e.message, retryable: true, retryAction: verify);
    } catch (_) {
      _fail(l.t('networkError'), retryable: true, retryAction: verify);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _handleGoogleSignIn() async {
    final l = AppLocalizations.of(context);
    if (authenticating) return;
    if (_googleServerClientId.isEmpty) {
      _fail(l.t('googleUnavailable'));
      return;
    }
    setState(() {
      googleLoading = true;
      error = null;
      _canRetry = false;
      _retryAction = null;
    });
    try {
      final google = GoogleSignIn(
        scopes: const ['email', 'profile'],
        serverClientId: _googleServerClientId,
      );
      final account = await google.signIn();
      if (account == null) return;
      final authentication = await account.authentication;
      final idToken = authentication.idToken;
      if (idToken == null || idToken.isEmpty) {
        _fail(l.t('googleFailed'), retryable: true, retryAction: _handleGoogleSignIn);
        return;
      }
      final result = await Api.instance.post('/auth/google', {
        'idToken': idToken,
        'locale': darbLocale.value.languageCode,
      });
      final tokens = extractValidAuthTokens(result);
      if (tokens == null) {
        _fail(
          l.t('invalidAuthResponse'),
          retryable: true,
          retryAction: _handleGoogleSignIn,
        );
        return;
      }
      await Api.instance.saveTokens(tokens);
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const AppShell()),
        );
      }
    } on ApiException catch (e) {
      _fail(e.message, retryable: true, retryAction: _handleGoogleSignIn);
    } catch (_) {
      _fail(
        l.t('googleFailed'),
        retryable: true,
        retryAction: _handleGoogleSignIn,
      );
    } finally {
      if (mounted) setState(() => googleLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      backgroundColor: DarbColors.canvas,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, _) => SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 470),
                child: FadeTransition(
                  opacity: CurvedAnimation(
                    parent: _entrance,
                    curve: DarbMotion.enter,
                  ),
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, .035),
                      end: Offset.zero,
                    ).animate(
                      CurvedAnimation(
                        parent: _entrance,
                        curve: DarbMotion.enter,
                      ),
                    ),
                    child: AnimatedBuilder(
                      animation: _shake,
                      builder: (context, child) => Transform.translate(
                        offset: Offset(_shakeX.value, 0),
                        child: child,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _languageBar(),
                          const SizedBox(height: 18),
                          _brandPanel(l),
                          const SizedBox(height: 18),
                          _formPanel(l),
                          const SizedBox(height: 18),
                          _securityNote(l),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _languageBar() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Row(
      children: [
        Tooltip(
          message: isDark
              ? dt('التبديل إلى الوضع النهاري')
              : dt('التبديل إلى الوضع الليلي'),
          child: IconButton(
            onPressed: authenticating
                ? null
                : () => DarbTheme.setMode(
                      isDark ? ThemeMode.light : ThemeMode.dark,
                    ),
            style: IconButton.styleFrom(
              backgroundColor: DarbColors.surface,
              foregroundColor: DarbColors.brandForeground,
              side: BorderSide(color: DarbColors.line),
              shape: const CircleBorder(),
              fixedSize: const Size(44, 44),
            ),
            icon: AnimatedSwitcher(
              duration: DarbMotion.effectiveDuration(
                context,
                DarbMotion.standard,
              ),
              switchInCurve: DarbMotion.enter,
              switchOutCurve: DarbMotion.exit,
              transitionBuilder: (child, animation) =>
                  DarbMotion.reduceMotion(context)
                      ? child
                      : RotationTransition(
                          turns: Tween<double>(begin: -.18, end: 0)
                              .animate(animation),
                          child: FadeTransition(
                            opacity: animation,
                            child: child,
                          ),
                        ),
              child: Icon(
                isDark ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
                key: ValueKey(isDark),
              ),
            ),
          ),
        ),
        const Spacer(),
        _languageChip('AR', const Locale('ar')),
        const SizedBox(width: 6),
        _languageChip('EN', const Locale('en')),
        const SizedBox(width: 6),
        _languageChip('TR', const Locale('tr')),
      ],
    );
  }

  Widget _brandPanel(AppLocalizations l) => Container(
        decoration: BoxDecoration(
          color: DarbColors.forest,
          borderRadius: BorderRadius.circular(DarbRadius.hero),
          boxShadow: DarbElevation.cardFor(Theme.of(context).brightness),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            const Positioned.fill(child: DarbCityCarousel()),
            PositionedDirectional(
              top: -55,
              end: -48,
              child: IgnorePointer(
                child: Container(
                  width: 170,
                  height: 170,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white.withValues(alpha: .07),
                      width: 22,
                    ),
                  ),
                ),
              ),
            ),
            IgnorePointer(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(22, 24, 22, 25),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 54,
                          height: 54,
                          decoration: BoxDecoration(
                            color: DarbColors.lime,
                            borderRadius: BorderRadius.circular(19),
                            boxShadow: [
                              BoxShadow(
                                color: DarbColors.lime.withValues(alpha: .2),
                                blurRadius: 22,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            'د',
                            style: TextStyle(
                              color: DarbColors.forest,
                              fontSize: 37,
                              height: 1,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 11,
                            vertical: 7,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: .10),
                            borderRadius: BorderRadius.circular(DarbRadius.pill),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: .14),
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.route_rounded,
                                color: DarbColors.lime,
                                size: 15,
                              ),
                              const SizedBox(width: 6),
                              const Text(
                                'DARB',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.8,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 48),
                    Text(
                      l.t('welcomeTitle'),
                      textAlign: TextAlign.start,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 25,
                        height: 1.25,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 9),
                    Text(
                      l.t('welcomeSubtitle'),
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: .78),
                        fontSize: 13,
                        height: 1.65,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _featurePill(
                          Icons.storefront_rounded,
                          l.t('featureStores'),
                        ),
                        _featurePill(
                          Icons.local_shipping_rounded,
                          l.t('featureDelivery'),
                        ),
                        _featurePill(
                          Icons.near_me_rounded,
                          l.t('featureNearby'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );

  Widget _featurePill(IconData icon, String label) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: .10),
          borderRadius: BorderRadius.circular(DarbRadius.pill),
          border: Border.all(color: Colors.white.withValues(alpha: .12)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: DarbColors.lime, size: 13),
            const SizedBox(width: 5),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      );

  Widget _formPanel(AppLocalizations l) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final primaryCtaBg = isDark ? DarbColors.mint : DarbColors.forest;
    final primaryCtaFg = isDark ? DarbColors.forest : Colors.white;

    return DarbSurfaceCard(
      padding: const EdgeInsets.all(20),
      borderRadius: DarbRadius.xl,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Text(
                l.t('phoneStep'),
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: !sent ? FontWeight.w800 : FontWeight.w600,
                  color: !sent ? DarbColors.brandForeground : DarbColors.muted,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: DarbStepProgress(
                  totalSteps: 2,
                  currentStep: sent ? 1 : 0,
                  height: 5,
                ),
              ),
              const SizedBox(width: 10),
              Text(
                l.t('otpStep'),
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: sent ? FontWeight.w800 : FontWeight.w600,
                  color: sent ? DarbColors.brandForeground : DarbColors.muted,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          AnimatedSwitcher(
            duration: DarbMotion.effectiveDuration(
              context,
              DarbMotion.standard,
            ),
            switchInCurve: DarbMotion.enter,
            switchOutCurve: DarbMotion.exit,
            child: Column(
              key: ValueKey('auth_step_$sent'),
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  sent ? l.t('otpTitle') : l.t('phoneTitle'),
                  textAlign: TextAlign.start,
                  style: TextStyle(
                    color: DarbColors.ink,
                    fontSize: 19,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  sent ? l.t('otpSubtitle') : l.t('phoneSubtitle'),
                  textAlign: TextAlign.start,
                  style: TextStyle(
                    color: DarbColors.muted,
                    fontSize: 12,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 18),
                if (!sent) ...[
                  Text(
                    l.t('phoneLabel'),
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      color: DarbColors.ink,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 9),
                  _phoneField(),
                ] else ...[
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: DarbStatusBadge(
                      label: '${l.t('otpSentTo')} +963 ${digits.substring(1)}',
                      tone: DarbTone.info,
                      icon: Icons.sms_outlined,
                    ),
                  ),
                  TextField(
                    key: const ValueKey('otp_code_field'),
                    controller: code,
                    enabled: !authenticating,
                    keyboardType: TextInputType.number,
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.center,
                    maxLength: 6,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(6),
                    ],
                    style: TextStyle(
                      fontSize: 23,
                      letterSpacing: 9,
                      fontWeight: FontWeight.w800,
                      color: DarbColors.ink,
                    ),
                    decoration: _inputDecoration(l.t('otpLabel')),
                    onChanged: (_) => setState(() {
                      error = null;
                      _canRetry = false;
                      _retryAction = null;
                    }),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: name,
                    enabled: !authenticating,
                    decoration: _inputDecoration(l.t('nameLabel')),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(
                        onPressed: authenticating
                            ? null
                            : () {
                                _resendTimer?.cancel();
                                setState(() {
                                  sent = false;
                                  _resendCooldown = 0;
                                  code.clear();
                                  error = null;
                                  _canRetry = false;
                                  _retryAction = null;
                                });
                              },
                        child: Text(l.t('changePhone')),
                      ),
                      TextButton(
                        onPressed:
                            authenticating || _resendCooldown > 0
                                ? null
                                : requestCode,
                        child: Text(
                          _resendCooldown > 0
                              ? '${l.t('resendIn')} ${_resendCooldown}s'
                              : l.t('resendOtp'),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          AnimatedSize(
            duration: DarbMotion.effectiveDuration(
              context,
              DarbMotion.standard,
            ),
            curve: DarbMotion.enter,
            child: error == null
                ? const SizedBox.shrink()
                : Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: DarbColors.danger.withValues(alpha: .09),
                        borderRadius: BorderRadius.circular(DarbRadius.md),
                        border: Border.all(
                          color: DarbColors.danger.withValues(alpha: .22),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            Icons.error_outline_rounded,
                            color: DarbColors.danger,
                            size: 19,
                          ),
                          const SizedBox(width: 9),
                          Expanded(
                            child: Text(
                              error!,
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                color: DarbColors.danger,
                                fontSize: 12,
                                height: 1.45,
                              ),
                            ),
                          ),
                          if (_canRetry && _retryAction != null) ...[
                            const SizedBox(width: 8),
                            TextButton(
                              onPressed: authenticating ? null : _retryAction,
                              style: TextButton.styleFrom(
                                foregroundColor: DarbColors.danger,
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                minimumSize: Size.zero,
                                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                              ),
                              child: Text(l.t('retry')),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
          ),
          const SizedBox(height: 17),
          SizedBox(
            height: 55,
            child: FilledButton(
              key: const ValueKey('login_primary_cta'),
              onPressed: authenticating ||
                      (!sent && !validPhone) ||
                      (sent && !validOtp)
                  ? null
                  : (sent ? verify : requestCode),
              style: FilledButton.styleFrom(
                backgroundColor: primaryCtaBg,
                foregroundColor: primaryCtaFg,
                disabledBackgroundColor: DarbColors.borderStrong,
                disabledForegroundColor:
                    DarbColors.muted.withValues(alpha: .8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(DarbRadius.md),
                ),
                elevation: 0,
              ),
              child: busy
                  ? SizedBox(
                      width: 21,
                      height: 21,
                      child: CircularProgressIndicator(
                        color: primaryCtaFg,
                        strokeWidth: 2.2,
                      ),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          sent ? l.t('verify') : l.t('sendOtp'),
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(width: 9),
                        Icon(DarbIcons.arrowForward(context), size: 18),
                      ],
                    ),
            ),
          ),
          if (!sent) ...[
            const SizedBox(height: 20),
            Row(
              children: [
                const Expanded(child: Divider()),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Text(
                    l.t('or'),
                    style: TextStyle(
                      color: DarbColors.muted,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const Expanded(child: Divider()),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 54,
              child: OutlinedButton(
                key: const ValueKey('login_google_cta'),
                onPressed: authenticating ? null : _handleGoogleSignIn,
                style: OutlinedButton.styleFrom(
                  backgroundColor: DarbColors.surface,
                  foregroundColor: DarbColors.ink,
                  side: BorderSide(color: DarbColors.line),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(DarbRadius.md),
                  ),
                ),
                child: googleLoading
                    ? SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: DarbColors.brandForeground,
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _googleMark(),
                          const SizedBox(width: 10),
                          Text(
                            l.t('google'),
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _securityNote(AppLocalizations l) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.verified_user_outlined,
            size: 15,
            color: DarbColors.muted,
          ),
          const SizedBox(width: 7),
          Flexible(
            child: Text(
              l.t('secure'),
              textAlign: TextAlign.center,
              style: TextStyle(
                color: DarbColors.muted,
                fontSize: 10.5,
                height: 1.45,
              ),
            ),
          ),
        ],
      );

  Widget _languageChip(String label, Locale locale) {
    final selected = darbLocale.value.languageCode == locale.languageCode;
    final activeBg = Theme.of(context).brightness == Brightness.dark
        ? DarbColors.mint
        : DarbColors.forest;
    final activeFg = Theme.of(context).brightness == Brightness.dark
        ? DarbColors.forest
        : Colors.white;
    return DarbPressScale(
      onTap: authenticating
          ? null
          : () {
              darbLocale.value = locale;
              _clearError();
            },
      child: AnimatedContainer(
        duration: DarbMotion.effectiveDuration(context, DarbMotion.fast),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? activeBg : DarbColors.surface,
          borderRadius: BorderRadius.circular(DarbRadius.pill),
          border: Border.all(
            color: selected ? activeBg : DarbColors.line,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 10.5,
            fontWeight: FontWeight.w900,
            color: selected ? activeFg : DarbColors.muted,
          ),
        ),
      ),
    );
  }

  Widget _phoneField() => Directionality(
        textDirection: TextDirection.ltr,
        child: AnimatedContainer(
          duration: DarbMotion.effectiveDuration(context, DarbMotion.fast),
          height: 60,
          decoration: BoxDecoration(
            color: DarbColors.surface,
            borderRadius: BorderRadius.circular(DarbRadius.md),
            border: Border.all(
              color: validPhone ? DarbColors.success : DarbColors.line,
              width: validPhone ? 1.5 : 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                height: double.infinity,
                decoration: BoxDecoration(
                  border: Border(right: BorderSide(color: DarbColors.line)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('🇸🇾', style: TextStyle(fontSize: 19)),
                    const SizedBox(width: 7),
                    Text(
                      '+963',
                      style: TextStyle(
                        color: DarbColors.ink,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: TextField(
                  key: const ValueKey('login_phone_field'),
                  controller: phone,
                  keyboardType: TextInputType.phone,
                  textDirection: TextDirection.ltr,
                  textAlign: TextAlign.left,
                  enabled: !authenticating,
                  inputFormatters: [SyrianPhoneFormatter()],
                  style: TextStyle(
                    color: DarbColors.ink,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    letterSpacing: .3,
                  ),
                  decoration: const InputDecoration(
                    hintText: '09X XXX XXXX',
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    filled: false,
                    contentPadding: EdgeInsets.symmetric(horizontal: 13),
                  ),
                  onChanged: (_) => setState(() {
                    error = null;
                    _canRetry = false;
                    _retryAction = null;
                  }),
                ),
              ),
              if (validPhone)
                Padding(
                  padding: const EdgeInsetsDirectional.only(end: 12),
                  child: Icon(
                    Icons.check_circle_rounded,
                    color: DarbColors.success,
                    size: 20,
                  ),
                ),
            ],
          ),
        ),
      );

  InputDecoration _inputDecoration(String label) => InputDecoration(
        labelText: label,
        filled: true,
        fillColor: DarbColors.surface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(DarbRadius.md),
          borderSide: BorderSide(color: DarbColors.line),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(DarbRadius.md),
          borderSide: BorderSide(color: DarbColors.line),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(DarbRadius.md),
          borderSide: BorderSide(color: DarbColors.brandForeground, width: 1.5),
        ),
      );

  Widget _googleMark() => Container(
        width: 25,
        height: 25,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(DarbRadius.pill),
          border: Border.all(color: DarbColors.line),
        ),
        child: const Text(
          'G',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w900,
            color: Color(0xFF4285F4),
          ),
        ),
      );
}

class SyrianPhoneFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final raw = newValue.text.replaceAll(RegExp(r'\D'), '');
    final digits = raw.length > 10 ? raw.substring(0, 10) : raw;
    final out = StringBuffer();
    for (var i = 0; i < digits.length; i++) {
      if (i == 3 || i == 6) out.write(' ');
      out.write(digits[i]);
    }
    final text = out.toString();
    return TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    );
  }
}
