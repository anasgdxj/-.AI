# Backend deployment and local secure setup

## Repository layout

The original backend and Android sources remain in `DARB-source.zip`. Versioned backend patches, health checks, and Prisma migrations live in the repository under `backend/`. The deployment build extracts the archive, then overlays the current backend source patches and migration history before compiling.

## Database migrations

The repository contains the reviewed initial Prisma migration at `backend/prisma/migrations/20261116162000_initial/`. It creates the application schema, enables PostGIS, adds spatial GiST indexes, and enforces the Syrian mobile-number format.

The initial migration was applied successfully in CI to a disposable PostgreSQL 16/PostGIS database using `prisma migrate deploy`. Backend CI applies the committed migration to a fresh PostGIS service before building and running tests.

For local development, extract `DARB-source.zip`, copy the repository's `backend/prisma/migrations/` directory into the extracted backend, set `DATABASE_URL`, then run:

```sh
npx prisma generate
npx prisma migrate deploy
```

Do not use `prisma db push` as a production migration strategy. Review and commit every future schema change as a new migration. Do not edit an already-applied migration; create a follow-up migration instead.

## Prepare secrets

Copy `.env.example` to `.env` for local development and replace every placeholder. Generate separate values for PostgreSQL, Redis, JWT access, JWT refresh, and OTP secrets. Never commit a real `.env`. Keep the initial administrator phone operator-controlled.

## Local stack

Extract `DARB-source.zip`, then run Docker Compose from the extracted `darb-project/backend/` directory. The Compose file starts PostgreSQL/PostGIS, Redis, and the API on local ports. Ensure the migration directory from the repository is copied into the extracted backend before starting the API.

## Health endpoints

- Liveness: `GET /api/v1/healthz` — confirms the Node process responds.
- Readiness: `GET /api/v1/readyz` — confirms Redis responds and the PostgreSQL schema has been initialized (checks for the `User` table).

A passing liveness check does not mean the database schema is ready.

## Zero-cost preview deployment

The root `render.yaml` now creates only the Render Free API service. PostgreSQL and Redis are external services to avoid relying on Render Free Postgres (30-day expiry) and ephemeral Render Key Value storage.

See [FREE-DEPLOYMENT.md](../FREE-DEPLOYMENT.md) for the exact setup using:
- Render Free Web Service for the NestJS API (Frankfurt).
- Supabase Free PostgreSQL (500 MB); enable PostGIS and verify extension schema/search path compatibility before applying migrations.
- Upstash Redis Free (256 MB / 500K commands per month).

The API requires `DATABASE_URL` and `REDIS_URL`. Keep the generated `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET`, and `OTP_SECRET`. The implemented MsgPlus adapter is configured with `SMS_PROVIDER=msgplus`, `MSGPLUS_API_KEY`, `MSGPLUS_SENDER_NAME`, and `MSGPLUS_TEMPLATE_ID=3`. The sender name and template must be approved by MsgPlus. Do not use the legacy `SMS_API_URL` / `SMS_API_KEY` names for this adapter. No live SMS delivery is considered verified until an explicitly approved test is completed; do not send test messages or consume prepaid balance without the service owner's approval.

The free tiers can sleep, pause, or enforce quotas. They are not suitable for real customer data, live orders, payments, or driver dispatch. Do not deploy real users until backups, restore procedures, availability, resource limits, and security have been reviewed.

## Production requirements

- Select durable paid resources with managed database backups and persistent Redis-compatible storage; review pricing before confirming.
- Set `NODE_ENV=production` and use strong, distinct JWT and OTP secrets.
- Configure a real SMS provider that supports delivery to Syrian numbers. The current HTTP adapter sends a generic JSON body `{ "to": "+963...", "message": "..." }`; adapt it to the provider's documented API. This is not a verified Syrian SMS integration.
- Keep the SMS API URL and key in the hosting provider's secret manager. Console SMS is not suitable for production.
- Terminate HTTPS at the hosting provider's trusted edge. Do not expose PostgreSQL or Redis publicly.
- Back up PostgreSQL and test restoration before accepting real orders. Test role authorization, order lifecycle, OTP rate limits, refresh-token rotation/revocation, and driver tracking.

## Android build

```sh
cd mobile
flutter build apk --release --dart-define=API_BASE_URL=https://YOUR_API_HOST/api/v1
```

The API URL must be a real HTTPS endpoint reachable from the device. An emulator address is not a production URL.

## Remaining external integrations

Firebase Cloud Messaging, live maps/geocoding, and a production Syrian SMS provider still require real provider accounts and credentials. A successful CI build does not prove these integrations work.


## Google sign-in and driver tracking update

The API source overlay now includes Google ID-token verification (GOOGLE_SERVER_CLIENT_ID), server-side refresh-token rotation/revocation in Redis, atomic OTP verification, profile updates, approved-role assignment, and driver-location endpoints. The migration makes User.phone nullable for Google-only accounts and adds unique Google subject/email fields. Render applies it through prisma migrate deploy.

Google sign-in is not enabled until the same OAuth Web client ID is configured in Render and the Android OAuth client/package SHA-1 configuration is added to the mobile Firebase/Google project. Do not treat the button as live until a real Android device login succeeds. Driver GPS requires the user to grant foreground location permission and enable location services. Customer tracking is available only for the owning customer and active assigned/in-progress orders.

Firebase Cloud Messaging remains pending Firebase project configuration (google-services.json / app identifiers and service credentials).


## Firebase Cloud Messaging

The current source includes device-token registration and order-created/assigned/status push triggers. Configure FIREBASE_SERVICE_ACCOUNT_JSON in Render with the Firebase Admin service-account JSON. Configure FIREBASE_API_KEY, FIREBASE_APP_ID, FIREBASE_MESSAGING_SENDER_ID, and FIREBASE_PROJECT_ID as GitHub Actions secrets for Android builds. The app requests notification permission and registers its FCM token after login. Without these values push is intentionally disabled; order creation and status updates continue normally.


The first deployment with the city seed migration will activate 12 Syrian city records with Arabic, English, and Turkish names. It deliberately does not fabricate vendors, products, drivers, delivery fees, or commercial registrations. Approved sellers must add their real catalog, and delivery-zone prices must be entered by an administrator before paid delivery orders are enabled.

## Delivery-zone administration

An authenticated administrator can list, create, and update delivery zones through `/api/v1/admin/delivery-zones`. Each zone requires an active city, a non-negative `feeBase`, and a non-negative `feePerKm`. Order creation intentionally refuses a city without a configured delivery zone; do not set zero fees merely to bypass this guard.

Delivery pricing is configured once per city. feeBase is the fixed base fee; when feePerKm is greater than zero, the order service calculates the distance between the vendor GPS point and the customer address point using PostGIS geography distance, rounds up to the next started kilometre, and adds that charge. Both GPS points are required for per-kilometre pricing; orders are rejected rather than silently undercharged when either point is missing.
