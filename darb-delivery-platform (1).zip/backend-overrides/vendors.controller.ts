import { Body, Controller, Get, Param, Patch, Query, UseGuards } from '@nestjs/common';
import { Type } from 'class-transformer';
import { IsLatitude, IsLongitude, IsOptional, IsString, MaxLength, ValidateIf } from 'class-validator';
import { UserRole } from '@prisma/client';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/roles.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { VendorsService } from './vendors.service';

class UpdateVendorProfileDto {
  @IsOptional() @IsString() @MaxLength(60) name?: string;
  @IsOptional() @IsString() @MaxLength(40) type?: string;
  @IsOptional() @IsString() @MaxLength(500) description?: string;
  @IsOptional() @IsString() @MaxLength(300) address?: string;
  @ValidateIf(o => o.longitude !== undefined) @Type(() => Number) @IsLatitude() latitude?: number;
  @ValidateIf(o => o.latitude !== undefined) @Type(() => Number) @IsLongitude() longitude?: number;
}

@Controller('vendors')
export class VendorsController {
  constructor(private readonly vendors: VendorsService) {}

  @Get('mine') @UseGuards(JwtAuthGuard, RolesGuard) @Roles(UserRole.VENDOR)
  mine(@CurrentUser() user: { id: string }) {
    return this.vendors.mine(user.id);
  }

  @Patch('mine') @UseGuards(JwtAuthGuard, RolesGuard) @Roles(UserRole.VENDOR)
  updateMine(@CurrentUser() user: { id: string }, @Body() dto: UpdateVendorProfileDto) {
    return this.vendors.updateMine(user.id, dto);
  }

  @Get()
  list(@Query('cityId') cityId?: string, @Query('locale') locale = 'ar') {
    return this.vendors.list(cityId, locale);
  }

  @Get(':id')
  get(@Param('id') id: string, @Query('locale') locale = 'ar') {
    return this.vendors.get(id, locale);
  }
}
