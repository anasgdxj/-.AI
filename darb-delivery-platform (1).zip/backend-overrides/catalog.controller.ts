import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { Type } from 'class-transformer';
import { IsBoolean, IsInt, IsNumber, IsOptional, IsString, MaxLength, Min } from 'class-validator';
import { UserRole } from '@prisma/client';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/roles.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CatalogService } from './catalog.service';

class CreateProductDto {
  @IsString() @MaxLength(120) name!: string;
  @IsOptional() @IsString() @MaxLength(500) description?: string;
  @Type(() => Number) @IsNumber() @Min(0) price!: number;
  @IsOptional() @IsString() @MaxLength(3) currency?: string;
  @IsOptional() @IsString() @MaxLength(500) imageUrl?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) stockQty?: number;
  @IsOptional() @IsBoolean() isAvailable?: boolean;
}

class UpdateProductDto {
  @IsOptional() @IsString() @MaxLength(120) name?: string;
  @IsOptional() @IsString() @MaxLength(500) description?: string;
  @IsOptional() @Type(() => Number) @IsNumber() @Min(0) price?: number;
  @IsOptional() @IsBoolean() isAvailable?: boolean;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) stockQty?: number | null;
}

@Controller()
export class CatalogController {
  constructor(private readonly catalog: CatalogService) {}

  @Get('vendors/:vendorId/products')
  list(@Param('vendorId') vendorId: string, @Query('locale') locale = 'ar') {
    return this.catalog.list(vendorId, locale);
  }

  @Get('vendor/products') @UseGuards(JwtAuthGuard, RolesGuard) @Roles(UserRole.VENDOR)
  listMine(@CurrentUser() user: { id: string }, @Query('locale') locale = 'ar') {
    return this.catalog.listMine(user.id, locale);
  }

  @Post('vendor/products') @UseGuards(JwtAuthGuard, RolesGuard) @Roles(UserRole.VENDOR)
  create(@CurrentUser() user: { id: string }, @Body() dto: CreateProductDto) {
    return this.catalog.create(user.id, dto);
  }

  @Patch('vendor/products/:id') @UseGuards(JwtAuthGuard, RolesGuard) @Roles(UserRole.VENDOR)
  update(@CurrentUser() user: { id: string }, @Param('id') id: string, @Body() dto: UpdateProductDto) {
    return this.catalog.update(user.id, id, dto);
  }
}
