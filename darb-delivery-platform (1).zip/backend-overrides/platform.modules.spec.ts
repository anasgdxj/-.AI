import { BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { OrderStatus } from '@prisma/client';
import { AddressesService } from '../addresses/addresses.service';
import { CatalogService } from '../catalog/catalog.service';
import { DriversService } from '../drivers/drivers.service';
import { VendorsService } from '../vendors/vendors.service';
import { AdminController } from './admin.controller';

describe('Addresses, Catalog, Vendors, Drivers, and Admin extensions', () => {
  it('prevents deleting an address linked to existing orders', async () => {
    const prisma: any = {
      address: { findFirst: jest.fn().mockResolvedValue({ id: 'addr-1' }), delete: jest.fn() },
      order: { count: jest.fn().mockResolvedValue(2) },
    };
    const service = new AddressesService(prisma);

    await expect(service.remove('user-1', 'addr-1')).rejects.toBeInstanceOf(BadRequestException);
    expect(prisma.address.delete).not.toHaveBeenCalled();
  });

  it('deletes an unused customer address cleanly', async () => {
    const prisma: any = {
      address: { findFirst: jest.fn().mockResolvedValue({ id: 'addr-1' }), delete: jest.fn().mockResolvedValue({}) },
      order: { count: jest.fn().mockResolvedValue(0) },
    };
    const service = new AddressesService(prisma);

    await expect(service.remove('user-1', 'addr-1')).resolves.toEqual({ success: true });
    expect(prisma.address.delete).toHaveBeenCalledWith({ where: { id: 'addr-1' } });
  });

  it('blocks unapproved or foreign vendors from updating products', async () => {
    const prisma: any = {
      vendor: { findUnique: jest.fn().mockResolvedValue({ id: 'v-1', status: 'PENDING' }) },
      product: { findFirst: jest.fn() },
    };
    const catalog = new CatalogService(prisma);

    await expect(catalog.update('user-1', 'prod-1', { price: 500 })).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('updates product price, availability, stockQty, and translation inside transaction', async () => {
    const tx: any = {
      product: {
        update: jest.fn().mockResolvedValue({ id: 'prod-1' }),
        findUnique: jest.fn().mockResolvedValue({ id: 'prod-1', isAvailable: false, stockQty: 8 }),
      },
      productTranslation: {
        findUnique: jest.fn().mockResolvedValue({ id: 'tr-1' }),
        update: jest.fn(),
      },
    };
    const prisma: any = {
      vendor: { findUnique: jest.fn().mockResolvedValue({ id: 'v-1', status: 'APPROVED' }) },
      product: { findFirst: jest.fn().mockResolvedValue({ id: 'prod-1', vendorId: 'v-1' }) },
      $transaction: jest.fn((cb: (tx: any) => unknown) => cb(tx)),
    };
    const catalog = new CatalogService(prisma);

    const updated = await catalog.update('user-1', 'prod-1', {
      name: 'زيت زيتون',
      price: 12000,
      isAvailable: false,
      stockQty: 8,
    });

    expect(updated).toEqual({ id: 'prod-1', isAvailable: false, stockQty: 8 });
    expect(tx.product.update).toHaveBeenCalledWith({
      where: { id: 'prod-1' },
      data: { basePrice: 12000, isAvailable: false, stockQty: 8 },
    });
  });

  it('updates driver vehicleType only when city is valid or unchanged', async () => {
    const prisma: any = {
      driver: {
        findUnique: jest.fn().mockResolvedValue({ id: 'drv-1', userId: 'u-1' }),
        update: jest.fn().mockResolvedValue({ id: 'drv-1', status: 'APPROVED', isOnline: true, cityId: 'c-1', vehicleType: 'فان' }),
      },
      city: { findFirst: jest.fn().mockResolvedValue(null) },
    };
    const drivers = new DriversService(prisma);

    await expect(drivers.updateProfile('u-1', { cityId: 'bad-city' })).rejects.toBeInstanceOf(BadRequestException);
    const res = await drivers.updateProfile('u-1', { vehicleType: 'فان' });
    expect(res.vehicleType).toBe('فان');
  });

  it('rejects partial coordinates on VendorsService.updateMine', async () => {
    const prisma: any = { vendor: { findUnique: jest.fn() } };
    const vendors = new VendorsService(prisma);

    await expect(vendors.updateMine('u-1', { latitude: 33.5 })).rejects.toBeInstanceOf(BadRequestException);
  });

  it('rejects duplicate city code creation in AdminController and computes real stats', async () => {
    const prisma: any = {
      city: {
        findUnique: jest.fn().mockResolvedValue({ id: 'c-1' }),
        count: jest.fn().mockResolvedValue(4),
      },
      order: {
        count: jest.fn().mockResolvedValue(10),
        aggregate: jest.fn().mockResolvedValue({ _sum: { total: 50000 } }),
        findUnique: jest.fn().mockResolvedValue({ id: 'o-1', status: OrderStatus.DELIVERED, items: [] }),
      },
      vendor: { count: jest.fn().mockResolvedValue(2) },
      driver: { count: jest.fn().mockResolvedValue(3) },
      user: { count: jest.fn().mockResolvedValue(15) },
      $transaction: jest.fn((ops: Array<Promise<unknown>>) => Promise.all(ops)),
    };
    const admin = new AdminController(prisma);

    await expect(admin.createCity({ code: 'DAM', nameAr: 'دمشق' })).rejects.toBeInstanceOf(BadRequestException);
    await expect(admin.cancelOrder({ id: 'admin-1' }, 'o-1')).rejects.toBeInstanceOf(BadRequestException);

    const stats = await admin.stats();
    expect(stats.deliveredRevenue).toBe(50000);
    expect(stats.citiesActive).toBe(4);
    expect(stats.usersTotal).toBe(15);
  });

  it('throws NotFoundException when updating a non-existent city', async () => {
    const prisma: any = {
      city: { findUnique: jest.fn().mockResolvedValue(null) },
    };
    const admin = new AdminController(prisma);

    await expect(admin.updateCity('missing', { isActive: false })).rejects.toBeInstanceOf(NotFoundException);
  });
});
