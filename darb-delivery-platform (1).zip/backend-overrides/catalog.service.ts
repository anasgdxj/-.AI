import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class CatalogService {
  constructor(private readonly prisma: PrismaService) {}

  async list(vendorId: string, locale = 'ar') {
    const vendor = await this.prisma.vendor.findFirst({ where: { id: vendorId, status: 'APPROVED' }, select: { id: true } });
    if (!vendor) throw new NotFoundException('المتجر غير متاح');
    return this.prisma.product.findMany({
      where: { vendorId, isAvailable: true },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        basePrice: true,
        currency: true,
        isAvailable: true,
        stockQty: true,
        imageUrl: true,
        variants: { where: { isAvailable: true } },
        translations: { where: { locale: { in: [locale, 'ar'] } as any } },
      },
    });
  }

  async listMine(userId: string, locale = 'ar') {
    const vendor = await this.prisma.vendor.findUnique({ where: { userId }, select: { id: true, status: true } });
    if (!vendor) throw new ForbiddenException('لا يوجد ملف متجر لهذا الحساب');
    return this.prisma.product.findMany({
      where: { vendorId: vendor.id },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        basePrice: true,
        currency: true,
        isAvailable: true,
        stockQty: true,
        imageUrl: true,
        translations: { where: { locale: { in: [locale, 'ar'] } as any } },
      },
    });
  }

  async create(
    userId: string,
    dto: { name: string; description?: string; price: number; currency?: string; imageUrl?: string; stockQty?: number; isAvailable?: boolean },
  ) {
    const vendor = await this.prisma.vendor.findUnique({ where: { userId } });
    if (!vendor || vendor.status !== 'APPROVED') throw new ForbiddenException('حساب البائع غير معتمد');
    return this.prisma.product.create({
      data: {
        vendorId: vendor.id,
        basePrice: dto.price,
        currency: dto.currency ?? 'SYP',
        imageUrl: dto.imageUrl,
        stockQty: dto.stockQty,
        isAvailable: dto.isAvailable ?? true,
        translations: { create: { locale: 'ar', name: dto.name.trim(), description: dto.description?.trim() } },
      },
      include: { translations: true },
    });
  }

  async update(
    userId: string,
    productId: string,
    dto: { name?: string; description?: string; price?: number; isAvailable?: boolean; stockQty?: number | null },
  ) {
    const vendor = await this.prisma.vendor.findUnique({ where: { userId } });
    if (!vendor || vendor.status !== 'APPROVED') throw new ForbiddenException('حساب البائع غير معتمد');

    const product = await this.prisma.product.findFirst({ where: { id: productId, vendorId: vendor.id } });
    if (!product) throw new NotFoundException('المنتج غير موجود');

    return this.prisma.$transaction(async tx => {
      await tx.product.update({
        where: { id: productId },
        data: {
          ...(dto.price !== undefined ? { basePrice: dto.price } : {}),
          ...(dto.isAvailable !== undefined ? { isAvailable: dto.isAvailable } : {}),
          ...(dto.stockQty !== undefined ? { stockQty: dto.stockQty } : {}),
        },
      });
      if (dto.name !== undefined || dto.description !== undefined) {
        const existingAr = await tx.productTranslation.findUnique({
          where: { productId_locale: { productId, locale: 'ar' } },
        });
        if (existingAr) {
          await tx.productTranslation.update({
            where: { id: existingAr.id },
            data: {
              ...(dto.name !== undefined ? { name: dto.name.trim() } : {}),
              ...(dto.description !== undefined ? { description: dto.description.trim() } : {}),
            },
          });
        } else {
          await tx.productTranslation.create({
            data: {
              productId,
              locale: 'ar',
              name: (dto.name ?? 'منتج').trim(),
              description: dto.description?.trim(),
            },
          });
        }
      }
      return tx.product.findUnique({
        where: { id: productId },
        include: { translations: true },
      });
    });
  }
}
