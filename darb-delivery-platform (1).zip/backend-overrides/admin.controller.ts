import { BadRequestException, Body, Controller, Get, NotFoundException, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { DriverStatus, Locale, OrderStatus, OrderType, UserRole, VendorStatus } from '@prisma/client';
import { IsBoolean, IsEnum, IsInt, IsNumber, IsOptional, IsString, IsUUID, Matches, Max, MaxLength, Min } from 'class-validator';
import { Type } from 'class-transformer';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/roles.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PrismaService } from '../../prisma/prisma.service';

class VendorStatusDto { @IsEnum(VendorStatus) status!: VendorStatus; }
class DriverStatusDto { @IsEnum(DriverStatus) status!: DriverStatus; }

class AdminOrdersQueryDto {
  @IsOptional() @IsEnum(OrderStatus) status?: OrderStatus;
  @IsOptional() @IsEnum(OrderType) type?: OrderType;
  @IsOptional() @IsString() @MaxLength(80) search?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) page = 1;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(50) limit = 20;
}

class AdminUsersQueryDto {
  @IsOptional() @IsEnum(UserRole) role?: UserRole;
  @IsOptional() @IsString() @MaxLength(80) search?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) page = 1;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(50) limit = 20;
}

class CreateDeliveryZoneDto {
  @IsUUID() cityId!: string;
  @IsString() @MaxLength(80) name!: string;
  @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) feeBase!: number;
  @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) feePerKm!: number;
}

class UpdateDeliveryZoneDto {
  @IsOptional() @IsString() @MaxLength(80) name?: string;
  @IsOptional() @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) feeBase?: number;
  @IsOptional() @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) feePerKm?: number;
}

class CreateCityDto {
  @IsString() @MaxLength(16) @Matches(/^[A-Za-z0-9_-]{2,16}$/) code!: string;
  @IsOptional() @IsString() @MaxLength(3) defaultCurrency?: string;
  @IsOptional() @IsBoolean() isActive?: boolean;
  @IsString() @MaxLength(80) nameAr!: string;
  @IsOptional() @IsString() @MaxLength(80) nameEn?: string;
  @IsOptional() @IsString() @MaxLength(80) nameTr?: string;
}

class UpdateCityDto {
  @IsOptional() @IsString() @MaxLength(3) defaultCurrency?: string;
  @IsOptional() @IsBoolean() isActive?: boolean;
  @IsOptional() @IsString() @MaxLength(80) nameAr?: string;
  @IsOptional() @IsString() @MaxLength(80) nameEn?: string;
  @IsOptional() @IsString() @MaxLength(80) nameTr?: string;
}

@Controller('admin') @UseGuards(JwtAuthGuard, RolesGuard) @Roles(UserRole.ADMIN)
export class AdminController {
  constructor(private readonly prisma: PrismaService) {}

  @Get('stats')
  async stats() {
    const [
      ordersTotal,
      ordersPending,
      ordersDelivered,
      ordersCancelled,
      deliveredRevenueAgg,
      activeRevenueAgg,
      vendorsPending,
      vendorsApproved,
      driversPending,
      driversApproved,
      driversOnline,
      usersTotal,
      citiesActive,
    ] = await this.prisma.$transaction([
      this.prisma.order.count(),
      this.prisma.order.count({ where: { status: OrderStatus.PENDING } }),
      this.prisma.order.count({ where: { status: OrderStatus.DELIVERED } }),
      this.prisma.order.count({ where: { status: OrderStatus.CANCELLED } }),
      this.prisma.order.aggregate({ where: { status: OrderStatus.DELIVERED }, _sum: { total: true } }),
      this.prisma.order.aggregate({ where: { status: { not: OrderStatus.CANCELLED } }, _sum: { total: true } }),
      this.prisma.vendor.count({ where: { status: VendorStatus.PENDING } }),
      this.prisma.vendor.count({ where: { status: VendorStatus.APPROVED } }),
      this.prisma.driver.count({ where: { status: DriverStatus.PENDING } }),
      this.prisma.driver.count({ where: { status: DriverStatus.APPROVED } }),
      this.prisma.driver.count({ where: { status: DriverStatus.APPROVED, isOnline: true } }),
      this.prisma.user.count(),
      this.prisma.city.count({ where: { isActive: true } }),
    ]);

    return {
      ordersTotal,
      ordersPending,
      ordersActive: Math.max(0, ordersTotal - ordersDelivered - ordersCancelled),
      ordersDelivered,
      ordersCancelled,
      deliveredRevenue: Number(deliveredRevenueAgg._sum.total ?? 0),
      activeRevenue: Number(activeRevenueAgg._sum.total ?? 0),
      vendorsPending,
      vendorsApproved,
      driversPending,
      driversApproved,
      driversOnline,
      usersTotal,
      citiesActive,
    };
  }

  @Get('orders')
  async orders(@Query() query: AdminOrdersQueryDto) {
    const q = query.search?.trim();
    const where: Record<string, unknown> = {
      ...(query.status ? { status: query.status } : {}),
      ...(query.type ? { type: query.type } : {}),
      ...(q
        ? {
            OR: [
              { orderNumber: { contains: q, mode: 'insensitive' } },
              { customer: { name: { contains: q, mode: 'insensitive' } } },
              { customer: { phone: { contains: q } } },
            ],
          }
        : {}),
    };
    const page = query.page || 1;
    const limit = query.limit || 20;
    const [items, total] = await this.prisma.$transaction([
      this.prisma.order.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          city: { select: { code: true, names: true } },
          customer: { select: { name: true, phone: true, email: true } },
          vendor: { include: { translations: true } },
          driver: { include: { user: { select: { name: true, phone: true } } } },
          payment: true,
        },
      }),
      this.prisma.order.count({ where }),
    ]);
    return { items, total, page, limit, pages: Math.ceil(total / limit) };
  }

  @Patch('orders/:id/cancel')
  async cancelOrder(@CurrentUser() admin: { id: string }, @Param('id') id: string) {
    const existing = await this.prisma.order.findUnique({
      where: { id },
      select: { id: true, status: true, type: true, items: { select: { productId: true, quantity: true } } },
    });
    if (!existing) throw new NotFoundException('الطلب غير موجود');
    if (existing.status === OrderStatus.DELIVERED || existing.status === OrderStatus.CANCELLED) {
      throw new BadRequestException('لا يمكن إلغاء طلب منتهٍ أو ملغى مسبقاً');
    }

    return this.prisma.$transaction(async tx => {
      const changed = await tx.order.updateMany({
        where: { id, status: existing.status },
        data: { status: OrderStatus.CANCELLED },
      });
      if (changed.count !== 1) throw new BadRequestException('تم تحديث حالة الطلب؛ أعد المحاولة');
      for (const item of existing.items) {
        await tx.product.updateMany({
          where: { id: item.productId, stockQty: { not: null } },
          data: { stockQty: { increment: item.quantity } },
        });
      }
      if (existing.type === OrderType.PEER_DELIVERY) {
        await tx.deliveryOffer.updateMany({
          where: { orderId: id, status: 'PENDING' },
          data: { status: 'REJECTED' },
        });
      }
      await tx.orderStatusHistory.create({
        data: { orderId: id, status: OrderStatus.CANCELLED, changedBy: admin.id },
      });
      return tx.order.findUnique({ where: { id } });
    });
  }

  @Get('users')
  async users(@Query() query: AdminUsersQueryDto) {
    const q = query.search?.trim();
    const where: Record<string, unknown> = {
      ...(query.role ? { role: query.role } : {}),
      ...(q
        ? {
            OR: [
              { name: { contains: q, mode: 'insensitive' } },
              { phone: { contains: q } },
              { email: { contains: q, mode: 'insensitive' } },
            ],
          }
        : {}),
    };
    const page = query.page || 1;
    const limit = query.limit || 20;
    const [items, total] = await this.prisma.$transaction([
      this.prisma.user.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        select: {
          id: true,
          name: true,
          phone: true,
          email: true,
          role: true,
          locale: true,
          createdAt: true,
          _count: { select: { ordersAsCustomer: true } },
        },
      }),
      this.prisma.user.count({ where }),
    ]);
    return { items, total, page, limit, pages: Math.ceil(total / limit) };
  }

  @Get('cities')
  cities() {
    return this.prisma.city.findMany({
      orderBy: [{ isActive: 'desc' }, { code: 'asc' }],
      select: {
        id: true,
        code: true,
        defaultCurrency: true,
        supportedLocales: true,
        isActive: true,
        names: { select: { locale: true, name: true } },
        zone: { select: { id: true, name: true, feeBase: true, feePerKm: true } },
      },
    });
  }

  @Post('cities')
  async createCity(@Body() dto: CreateCityDto) {
    const code = dto.code.trim().toUpperCase();
    const currency = (dto.defaultCurrency ?? 'SYP').trim().toUpperCase();
    if (currency.length !== 3) throw new BadRequestException('رمز العملة يجب أن يكون 3 أحرف');
    if (await this.prisma.city.findUnique({ where: { code } })) {
      throw new BadRequestException('رمز المدينة موجود مسبقاً');
    }
    const names: Array<{ locale: Locale; name: string }> = [{ locale: Locale.ar, name: dto.nameAr.trim() }];
    if (dto.nameEn?.trim()) names.push({ locale: Locale.en, name: dto.nameEn.trim() });
    if (dto.nameTr?.trim()) names.push({ locale: Locale.tr, name: dto.nameTr.trim() });

    return this.prisma.city.create({
      data: {
        code,
        defaultCurrency: currency,
        supportedLocales: [Locale.ar, Locale.en, Locale.tr],
        isActive: dto.isActive ?? true,
        names: { create: names },
      },
      include: { names: true, zone: true },
    });
  }

  @Patch('cities/:id')
  async updateCity(@Param('id') id: string, @Body() dto: UpdateCityDto) {
    const existing = await this.prisma.city.findUnique({ where: { id } });
    if (!existing) throw new NotFoundException('المدينة غير موجودة');

    return this.prisma.$transaction(async tx => {
      if (dto.isActive !== undefined || dto.defaultCurrency !== undefined) {
        const currency = dto.defaultCurrency?.trim().toUpperCase();
        if (currency !== undefined && currency.length !== 3) {
          throw new BadRequestException('رمز العملة يجب أن يكون 3 أحرف');
        }
        await tx.city.update({
          where: { id },
          data: {
            ...(dto.isActive !== undefined ? { isActive: dto.isActive } : {}),
            ...(currency !== undefined ? { defaultCurrency: currency } : {}),
          },
        });
      }
      const localeEntries: Array<[Locale, string | undefined]> = [
        [Locale.ar, dto.nameAr],
        [Locale.en, dto.nameEn],
        [Locale.tr, dto.nameTr],
      ];
      for (const [locale, rawName] of localeEntries) {
        const trimmed = rawName?.trim();
        if (trimmed) {
          await tx.cityTranslation.upsert({
            where: { cityId_locale: { cityId: id, locale } },
            create: { cityId: id, locale, name: trimmed },
            update: { name: trimmed },
          });
        }
      }
      return tx.city.findUnique({ where: { id }, include: { names: true, zone: true } });
    });
  }

  @Get('delivery-zones') deliveryZones() {
    return this.prisma.deliveryZone.findMany({ orderBy: [{ cityId: 'asc' }, { name: 'asc' }], include: { city: { select: { id: true, code: true, names: true } } } });
  }
  @Post('delivery-zones') async createDeliveryZone(@Body() dto: CreateDeliveryZoneDto) {
    const city = await this.prisma.city.findFirst({ where: { id: dto.cityId, isActive: true }, select: { id: true } });
    if (!city) throw new BadRequestException('المدينة غير متاحة');
    if (await this.prisma.deliveryZone.findUnique({ where: { cityId: dto.cityId } })) throw new BadRequestException('تم إعداد رسوم هذه المدينة مسبقاً؛ عدّل الإعداد الموجود');
    return this.prisma.deliveryZone.create({ data: dto });
  }
  @Patch('delivery-zones/:id') updateDeliveryZone(@Param('id') id: string, @Body() dto: UpdateDeliveryZoneDto) {
    return this.prisma.deliveryZone.update({ where: { id }, data: dto });
  }

  @Get('vendors')
  vendors(@Query('status') status?: VendorStatus) {
    return this.prisma.vendor.findMany({
      where: status ? { status } : undefined,
      orderBy: { createdAt: 'desc' },
      include: { user: { select: { id: true, name: true, phone: true, email: true } }, translations: true, cities: { include: { city: { select: { id: true, code: true, names: true } } } }, location: true },
    });
  }

  @Get('vendors/pending') pendingVendors() {
    return this.prisma.vendor.findMany({ where: { status: VendorStatus.PENDING }, orderBy: { createdAt: 'asc' },
      include: { user: { select: { id: true, name: true, phone: true, email: true } }, translations: true, cities: { include: { city: { select: { id: true, code: true, names: true } } } }, location: true } });
  }
  @Patch('vendors/:id/status') async setVendorStatus(@Param('id') id: string, @Body() dto: VendorStatusDto) {
    return this.prisma.$transaction(async tx => {
      const vendor = await tx.vendor.update({ where: { id }, data: { status: dto.status } });
      if (dto.status === VendorStatus.APPROVED) await tx.user.update({ where: { id: vendor.userId }, data: { role: UserRole.VENDOR } });
      else await tx.user.updateMany({ where: { id: vendor.userId, role: UserRole.VENDOR }, data: { role: UserRole.CUSTOMER } });
      return vendor;
    });
  }

  @Get('drivers')
  drivers(@Query('status') status?: DriverStatus) {
    return this.prisma.driver.findMany({
      where: status ? { status } : undefined,
      orderBy: { createdAt: 'desc' },
      include: { user: { select: { id: true, name: true, phone: true, email: true } }, city: { select: { id: true, code: true, names: true } } },
    });
  }

  @Get('drivers/pending') pendingDrivers() {
    return this.prisma.driver.findMany({ where: { status: DriverStatus.PENDING }, orderBy: { createdAt: 'asc' },
      include: { user: { select: { id: true, name: true, phone: true, email: true } }, city: { select: { id: true, code: true, names: true } } } });
  }
  @Patch('drivers/:id/status') async setDriverStatus(@Param('id') id: string, @Body() dto: DriverStatusDto) {
    return this.prisma.$transaction(async tx => {
      const driver = await tx.driver.update({ where: { id }, data: { status: dto.status, ...(dto.status === DriverStatus.APPROVED ? {} : { isOnline: false }) } });
      if (dto.status === DriverStatus.APPROVED) await tx.user.update({ where: { id: driver.userId }, data: { role: UserRole.DRIVER } });
      else await tx.user.updateMany({ where: { id: driver.userId, role: UserRole.DRIVER }, data: { role: UserRole.CUSTOMER } });
      return driver;
    });
  }
}
