export type DashboardStatusFilter = 'active' | 'delivered' | 'all';

export interface DashboardOrderInput {
  id: string;
  orderNumber?: string;
  type?: 'VENDOR_ORDER' | 'PEER_DELIVERY' | string;
  status: string;
  total: number | string | null | undefined;
  currency?: string;
  createdAt: string;
}

export interface DailyMetricPoint {
  dateKey: string;
  shortLabel: string;
  ordersCount: number;
  deliveredCount: number;
  cancelledCount: number;
  revenue: number;
}

export interface DashboardKpis {
  totalOrders: number;
  totalRevenue: number;
  avgOrderValue: number;
  completionRate: number;
  deliveredCount: number;
  cancelledCount: number;
  peakOrdersDay: DailyMetricPoint | null;
}

export function toDateKey(input: string | Date): string | null {
  const d = input instanceof Date ? input : new Date(input);
  if (Number.isNaN(d.getTime())) return null;
  const year = d.getUTCFullYear();
  const month = String(d.getUTCMonth() + 1).padStart(2, '0');
  const day = String(d.getUTCDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatShortArabicDate(dateKey: string): string {
  const parts = dateKey.split('-');
  if (parts.length !== 3) return dateKey;
  return `${Number(parts[2])}/${Number(parts[1])}`;
}

export function buildDateRangeKeys(days: number, referenceDate: Date = new Date()): string[] {
  const count = Math.max(1, Math.min(90, Math.floor(days)));
  const endUtc = new Date(
    Date.UTC(
      referenceDate.getUTCFullYear(),
      referenceDate.getUTCMonth(),
      referenceDate.getUTCDate(),
    ),
  );
  const keys: string[] = [];
  for (let i = count - 1; i >= 0; i -= 1) {
    const d = new Date(endUtc);
    d.setUTCDate(endUtc.getUTCDate() - i);
    const key = toDateKey(d);
    if (key) keys.push(key);
  }
  return keys;
}

export function parseOrderAmount(total: number | string | null | undefined): number {
  const num = typeof total === 'number' ? total : Number(total);
  if (!Number.isFinite(num) || num < 0) return 0;
  return num;
}

export function filterOrdersForDashboard(
  orders: DashboardOrderInput[],
  statusFilter: DashboardStatusFilter,
): DashboardOrderInput[] {
  if (statusFilter === 'delivered') {
    return orders.filter((o) => o.status === 'DELIVERED');
  }
  if (statusFilter === 'active') {
    return orders.filter((o) => o.status !== 'CANCELLED');
  }
  return orders;
}

export function aggregateDailyMetrics(
  orders: DashboardOrderInput[],
  options: {
    days?: number;
    statusFilter?: DashboardStatusFilter;
    referenceDate?: Date;
  } = {},
): DailyMetricPoint[] {
  const days = options.days ?? 14;
  const statusFilter = options.statusFilter ?? 'active';
  const keys = buildDateRangeKeys(days, options.referenceDate);
  const byDay = new Map<string, DailyMetricPoint>();

  for (const dateKey of keys) {
    byDay.set(dateKey, {
      dateKey,
      shortLabel: formatShortArabicDate(dateKey),
      ordersCount: 0,
      deliveredCount: 0,
      cancelledCount: 0,
      revenue: 0,
    });
  }

  const filtered = filterOrdersForDashboard(orders, statusFilter);
  for (const order of filtered) {
    const key = toDateKey(order.createdAt);
    if (!key) continue;
    const bucket = byDay.get(key);
    if (!bucket) continue;

    bucket.ordersCount += 1;
    if (order.status === 'DELIVERED') bucket.deliveredCount += 1;
    if (order.status === 'CANCELLED') {
      bucket.cancelledCount += 1;
    } else {
      bucket.revenue += parseOrderAmount(order.total);
    }
  }

  return keys.map((k) => byDay.get(k)!);
}

export function computeDashboardKpis(
  dailyPoints: DailyMetricPoint[],
  ordersInRange: DashboardOrderInput[] = [],
): DashboardKpis {
  let totalOrders = 0;
  let totalRevenue = 0;
  let deliveredCount = 0;
  let cancelledCount = 0;
  let peakOrdersDay: DailyMetricPoint | null = null;

  for (const point of dailyPoints) {
    totalOrders += point.ordersCount;
    totalRevenue += point.revenue;
    deliveredCount += point.deliveredCount;
    cancelledCount += point.cancelledCount;
    if (!peakOrdersDay || point.ordersCount > peakOrdersDay.ordersCount) {
      peakOrdersDay = point;
    }
  }

  const dateSet = new Set(dailyPoints.map((p) => p.dateKey));
  const rawInWindow = ordersInRange.filter((o) => {
    const k = toDateKey(o.createdAt);
    return k !== null && dateSet.has(k);
  });

  const denominatorForCompletion =
    rawInWindow.length > 0 ? rawInWindow.length : totalOrders;
  const deliveredForCompletion =
    rawInWindow.length > 0
      ? rawInWindow.filter((o) => o.status === 'DELIVERED').length
      : deliveredCount;

  const revenueOrders = Math.max(0, totalOrders - cancelledCount);
  const avgOrderValue =
    revenueOrders > 0 ? Math.round(totalRevenue / revenueOrders) : 0;
  const completionRate =
    denominatorForCompletion > 0
      ? Math.round((deliveredForCompletion / denominatorForCompletion) * 100)
      : 0;

  return {
    totalOrders,
    totalRevenue: Math.round(totalRevenue),
    avgOrderValue,
    completionRate,
    deliveredCount,
    cancelledCount,
    peakOrdersDay: peakOrdersDay && peakOrdersDay.ordersCount > 0 ? peakOrdersDay : null,
  };
}

export function buildDemoOrders(referenceDate: Date = new Date()): DashboardOrderInput[] {
  const keys = buildDateRangeKeys(30, referenceDate);
  const orders: DashboardOrderInput[] = [];
  const statuses = ['DELIVERED', 'DELIVERED', 'DELIVERED', 'PICKED_UP', 'PREPARING', 'PENDING', 'CANCELLED'];
  const types: Array<'VENDOR_ORDER' | 'PEER_DELIVERY'> = ['VENDOR_ORDER', 'VENDOR_ORDER', 'PEER_DELIVERY'];
  let seq = 1040;

  keys.forEach((dateKey, dayIdx) => {
    const dailyCount = 4 + ((dayIdx * 3 + (dayIdx % 5) * 2) % 9);
    for (let i = 0; i < dailyCount; i += 1) {
      seq += 1;
      const isRecent = dayIdx >= keys.length - 2;
      const status = isRecent && i === 0
        ? 'PENDING'
        : statuses[(dayIdx + i * 2) % statuses.length];
      const type = types[(dayIdx + i) % types.length];
      const baseAmount = type === 'VENDOR_ORDER' ? 95000 : 32000;
      const variance = ((dayIdx * 17 + i * 29) % 14) * 15000;
      const hour = String(9 + ((i * 2) % 13)).padStart(2, '0');
      const minute = String((i * 11) % 60).padStart(2, '0');
      orders.push({
        id: `demo-ord-${seq}`,
        orderNumber: `DRB-${seq}`,
        type,
        status,
        total: baseAmount + variance,
        currency: 'SYP',
        createdAt: `${dateKey}T${hour}:${minute}:00.000Z`,
      });
    }
  });

  return orders.reverse();
}
