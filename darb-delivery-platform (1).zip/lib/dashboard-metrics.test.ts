import test from 'node:test';
import assert from 'node:assert/strict';
import {
  aggregateDailyMetrics,
  buildDateRangeKeys,
  buildDemoOrders,
  computeDashboardKpis,
  filterOrdersForDashboard,
  type DashboardOrderInput,
} from './dashboard-metrics';

const refDate = new Date('2026-11-21T12:00:00.000Z');

test('buildDateRangeKeys generates contiguous UTC days ending at referenceDate', () => {
  const keys = buildDateRangeKeys(7, refDate);
  assert.equal(keys.length, 7);
  assert.equal(keys[0], '2026-11-15');
  assert.equal(keys[6], '2026-11-21');
});

test('aggregateDailyMetrics fills zero-order days and excludes cancelled orders from revenue', () => {
  const sample: DashboardOrderInput[] = [
    { id: '1', status: 'DELIVERED', total: 120000, createdAt: '2026-11-20T10:00:00Z' },
    { id: '2', status: 'PREPARING', total: '80000', createdAt: '2026-11-20T14:00:00Z' },
    { id: '3', status: 'CANCELLED', total: 500000, createdAt: '2026-11-20T16:00:00Z' },
    { id: '4', status: 'DELIVERED', total: 50000, createdAt: '2026-11-21T09:00:00Z' },
  ];

  const activePoints = aggregateDailyMetrics(sample, {
    days: 3,
    statusFilter: 'active',
    referenceDate: refDate,
  });
  assert.equal(activePoints.length, 3);
  assert.deepEqual(
    activePoints.map((p) => [p.dateKey, p.ordersCount, p.revenue]),
    [
      ['2026-11-19', 0, 0],
      ['2026-11-20', 2, 200000],
      ['2026-11-21', 1, 50000],
    ],
  );

  const allPoints = aggregateDailyMetrics(sample, {
    days: 3,
    statusFilter: 'all',
    referenceDate: refDate,
  });
  assert.equal(allPoints[1].ordersCount, 3);
  assert.equal(allPoints[1].cancelledCount, 1);
  assert.equal(allPoints[1].revenue, 200000);
});

test('filterOrdersForDashboard supports delivered-only filtering', () => {
  const sample: DashboardOrderInput[] = [
    { id: '1', status: 'DELIVERED', total: 1000, createdAt: '2026-11-21T09:00:00Z' },
    { id: '2', status: 'PENDING', total: 2000, createdAt: '2026-11-21T10:00:00Z' },
    { id: '3', status: 'CANCELLED', total: 3000, createdAt: '2026-11-21T11:00:00Z' },
  ];
  assert.equal(filterOrdersForDashboard(sample, 'delivered').length, 1);
  assert.equal(filterOrdersForDashboard(sample, 'active').length, 2);
  assert.equal(filterOrdersForDashboard(sample, 'all').length, 3);
});

test('computeDashboardKpis computes totals, average order value, completion rate, and peak day', () => {
  const sample: DashboardOrderInput[] = [
    { id: '1', status: 'DELIVERED', total: 100000, createdAt: '2026-11-19T10:00:00Z' },
    { id: '2', status: 'DELIVERED', total: 200000, createdAt: '2026-11-20T10:00:00Z' },
    { id: '3', status: 'PENDING', total: 150000, createdAt: '2026-11-20T12:00:00Z' },
    { id: '4', status: 'CANCELLED', total: 90000, createdAt: '2026-11-21T12:00:00Z' },
  ];

  const points = aggregateDailyMetrics(sample, {
    days: 3,
    statusFilter: 'active',
    referenceDate: refDate,
  });
  const kpis = computeDashboardKpis(points, sample);

  assert.equal(kpis.totalOrders, 3);
  assert.equal(kpis.totalRevenue, 450000);
  assert.equal(kpis.avgOrderValue, 150000);
  assert.equal(kpis.completionRate, 50);
  assert.equal(kpis.peakOrdersDay?.dateKey, '2026-11-20');
  assert.equal(kpis.peakOrdersDay?.ordersCount, 2);
});

test('buildDemoOrders produces deterministic 30-day order history', () => {
  const a = buildDemoOrders(refDate);
  const b = buildDemoOrders(refDate);
  assert.equal(a.length, b.length);
  assert.ok(a.length >= 120);
  const points30 = aggregateDailyMetrics(a, { days: 30, statusFilter: 'active', referenceDate: refDate });
  assert.equal(points30.length, 30);
  assert.ok(points30.every((p) => p.ordersCount > 0 && p.revenue > 0));
});
